const http = require('http');
const fs = require('fs');
const path = require('path');

// Create a simple HTTP server
const server = http.createServer((req, res) => {
  console.log('Request received:', req.method, req.url);
  
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }
  
  // Serve index.html for all routes
  fs.readFile(path.join(__dirname, 'index.html'), (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      res.writeHead(500, {'Content-Type': 'text/plain'});
      res.end('Internal Server Error');
      return;
    }
    
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(data);
  });
});

// Listen on port 5000
console.log('Starting simple server on 0.0.0.0:5000');
server.listen(5000, '0.0.0.0', () => {
  console.log('Simple server is running on port 5000');
});