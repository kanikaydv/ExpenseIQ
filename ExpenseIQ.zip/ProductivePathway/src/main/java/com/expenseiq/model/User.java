package com.expenseiq.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Entity class representing a user in the system.
 * 
 * This class implements UserDetails for Spring Security integration.
 */
@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"expenses", "incomes", "budgets", "categories", "notifications"})
@ToString(exclude = {"expenses", "incomes", "budgets", "categories", "notifications"})
public class User implements UserDetails {
    
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "first_name", nullable = false, length = 50)
    private String firstName;
    
    @Column(name = "last_name", nullable = false, length = 50)
    private String lastName;
    
    @Column(nullable = false, unique = true)
    private String email;
    
    @Column(nullable = false)
    private String password;
    
    private String currency;
    
    private String locale;
    
    private String theme;
    
    @Column(name = "registration_date")
    private LocalDateTime registrationDate;
    
    @Column(name = "last_login_date")
    private LocalDateTime lastLoginDate;
    
    private boolean active;
    
    private String role;
    
    @Column(name = "email_notifications")
    private boolean emailNotifications;
    
    @Column(name = "monthly_report_enabled")
    private boolean monthlyReportEnabled;
    
    @Column(name = "bill_reminder_enabled")
    private boolean billReminderEnabled;
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Expense> expenses = new ArrayList<>();
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Income> incomes = new ArrayList<>();
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Budget> budgets = new ArrayList<>();
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Category> categories = new ArrayList<>();
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Notification> notifications = new ArrayList<>();
    
    /**
     * Pre-persist callback to set default values.
     */
    @PrePersist
    public void prePersist() {
        this.registrationDate = LocalDateTime.now();
        this.active = true;
        
        if (this.role == null) {
            this.role = "ROLE_USER";
        }
        
        if (this.currency == null) {
            this.currency = "USD";
        }
        
        if (this.locale == null) {
            this.locale = "en_US";
        }
        
        if (this.theme == null) {
            this.theme = "light";
        }
    }
    
    /**
     * Records a login event by updating the last login timestamp.
     */
    public void recordLogin() {
        this.lastLoginDate = LocalDateTime.now();
    }
    
    /**
     * Returns the full name of the user.
     * 
     * @return The user's first and last name combined
     */
    public String getFullName() {
        return firstName + " " + lastName;
    }

    /**
     * Returns the authorities granted to the user.
     * 
     * @return A collection of granted authorities
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Set<GrantedAuthority> authorities = new HashSet<>();
        authorities.add(new SimpleGrantedAuthority(this.role));
        return authorities;
    }

    /**
     * Returns the username used to authenticate the user.
     * 
     * @return The user's email as the username
     */
    @Override
    public String getUsername() {
        return this.email;
    }

    /**
     * Indicates whether the user's account has expired.
     * 
     * @return true if the user's account is valid (non-expired)
     */
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    /**
     * Indicates whether the user is locked or unlocked.
     * 
     * @return true if the user is not locked
     */
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    /**
     * Indicates whether the user's credentials have expired.
     * 
     * @return true if the user's credentials are valid (non-expired)
     */
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    /**
     * Indicates whether the user is enabled or disabled.
     * 
     * @return true if the user is enabled
     */
    @Override
    public boolean isEnabled() {
        return this.active;
    }
}
