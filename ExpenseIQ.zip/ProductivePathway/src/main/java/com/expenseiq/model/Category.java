package com.expenseiq.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Entity class representing a transaction category in the system.
 * 
 * Categories can be used to classify both expenses and incomes.
 */
@Entity
@Table(name = "categories")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"expenses", "incomes", "budgets"})
@ToString(exclude = {"expenses", "incomes", "budgets"})
public class Category {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    private String description;
    
    private String icon;
    
    @Column(nullable = false)
    private String type; // EXPENSE, INCOME
    
    @Column(name = "is_default")
    private boolean isDefault;
    
    private String color;
    
    @ManyToOne(fetch = FetchType.LAZY)
    private User user; // null for system categories
    
    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Expense> expenses = new ArrayList<>();
    
    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Income> incomes = new ArrayList<>();
    
    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Budget> budgets = new ArrayList<>();
    
    /**
     * Checks if this is an expense category.
     * 
     * @return true if this is an expense category
     */
    public boolean isExpenseCategory() {
        return "EXPENSE".equals(type);
    }
    
    /**
     * Checks if this is an income category.
     * 
     * @return true if this is an income category
     */
    public boolean isIncomeCategory() {
        return "INCOME".equals(type);
    }
    
    /**
     * Checks if this is a system-wide default category.
     * 
     * @return true if this is a default category
     */
    public boolean isSystemCategory() {
        return user == null;
    }
}
