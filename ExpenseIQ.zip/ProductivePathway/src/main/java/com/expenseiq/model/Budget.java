package com.expenseiq.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity class representing a budget in the system.
 * 
 * A budget defines spending limits for a specific category or overall expenses
 * within a defined time period.
 */
@Entity
@Table(name = "budgets")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Budget {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;
    
    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;
    
    @Column(name = "end_date", nullable = false)
    private LocalDate endDate;
    
    @Column(name = "created_at")
    private LocalDate createdAt;
    
    @Column(length = 20)
    private String period; // monthly, yearly, etc.
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category; // Optional - if null, it's a total budget
    
    /**
     * Pre-persist callback to set creation date.
     */
    public void prePersist() {
        this.createdAt = LocalDate.now();
    }
    
    /**
     * Checks if this budget is currently active.
     * 
     * @return true if the current date is within the budget period
     */
    public boolean isActive() {
        LocalDate now = LocalDate.now();
        return !now.isBefore(startDate) && !now.isAfter(endDate);
    }
    
    /**
     * Checks if this budget is expired.
     * 
     * @return true if the current date is after the end date
     */
    public boolean isExpired() {
        return LocalDate.now().isAfter(endDate);
    }
}
