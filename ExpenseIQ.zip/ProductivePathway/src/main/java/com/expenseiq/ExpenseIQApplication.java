package com.expenseiq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main application class for ExpenseIQ.
 * 
 * This is the entry point for the ExpenseIQ personal finance manager application.
 * It enables scheduling for periodic tasks like notifications and budget alerts.
 * 
 * @author ExpenseIQ Team
 */
@SpringBootApplication
@EnableScheduling
public class ExpenseIQApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExpenseIQApplication.class, args);
    }
}
