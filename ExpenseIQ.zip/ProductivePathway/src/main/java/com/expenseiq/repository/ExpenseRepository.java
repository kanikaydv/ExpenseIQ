package com.expenseiq.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.expenseiq.model.Expense;

/**
 * Repository interface for Expense entities.
 * 
 * This interface provides methods to interact with expense data in the database.
 */
@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    
    /**
     * Finds all expenses belonging to a user.
     * 
     * @param userId The ID of the user
     * @return A list of expenses
     */
    List<Expense> findByUserId(Long userId);
    
    /**
     * Finds an expense by ID and user ID.
     * 
     * @param id The ID of the expense
     * @param userId The ID of the user
     * @return An Optional containing the expense if found
     */
    Optional<Expense> findByIdAndUserId(Long id, Long userId);
    
    /**
     * Finds expenses in a date range.
     * 
     * @param userId The ID of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return A list of expenses in the date range
     */
    List<Expense> findByUserIdAndDateBetween(Long userId, LocalDate startDate, LocalDate endDate);
    
    /**
     * Finds expenses in a date range, paginated.
     * 
     * @param userId The ID of the user
     * @param startDate The start date
     * @param endDate The end date
     * @param pageable Pagination information
     * @return A page of expenses
     */
    Page<Expense> findByUserIdAndDateBetween(Long userId, LocalDate startDate, LocalDate endDate, Pageable pageable);
    
    /**
     * Finds expenses for a specific category.
     * 
     * @param userId The ID of the user
     * @param categoryId The ID of the category
     * @return A list of expenses for the category
     */
    List<Expense> findByUserIdAndCategoryId(Long userId, Long categoryId);
    
    /**
     * Finds expenses for a specific category in a date range.
     * 
     * @param userId The ID of the user
     * @param categoryId The ID of the category
     * @param startDate The start date
     * @param endDate The end date
     * @return A list of expenses for the category in the date range
     */
    List<Expense> findByUserIdAndCategoryIdAndDateBetween(
            Long userId, Long categoryId, LocalDate startDate, LocalDate endDate);
    
    /**
     * Calculates the sum of expenses in a date range.
     * 
     * @param userId The ID of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return The sum of expenses, or zero if none exist
     */
    @Query("SELECT COALESCE(SUM(e.amount), 0) FROM Expense e WHERE e.user.id = :userId " +
           "AND e.date BETWEEN :startDate AND :endDate")
    BigDecimal sumExpensesByDateRange(@Param("userId") Long userId,
                                     @Param("startDate") LocalDate startDate,
                                     @Param("endDate") LocalDate endDate);
    
    /**
     * Calculates the sum of expenses for a specific category in a date range.
     * 
     * @param userId The ID of the user
     * @param categoryId The ID of the category
     * @param startDate The start date
     * @param endDate The end date
     * @return The sum of expenses, or zero if none exist
     */
    @Query("SELECT COALESCE(SUM(e.amount), 0) FROM Expense e WHERE e.user.id = :userId " +
           "AND e.category.id = :categoryId AND e.date BETWEEN :startDate AND :endDate")
    BigDecimal sumExpensesByCategoryAndDateRange(@Param("userId") Long userId,
                                              @Param("categoryId") Long categoryId,
                                              @Param("startDate") LocalDate startDate,
                                              @Param("endDate") LocalDate endDate);
    
    /**
     * Aggregates expenses by category for a date range.
     * 
     * @param userId The ID of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return A list of category name and sum pairs
     */
    @Query("SELECT c.name, COALESCE(SUM(e.amount), 0) FROM Expense e " +
           "JOIN e.category c WHERE e.user.id = :userId " +
           "AND e.date BETWEEN :startDate AND :endDate " +
           "GROUP BY c.name ORDER BY SUM(e.amount) DESC")
    List<Object[]> sumExpensesByCategory(@Param("userId") Long userId,
                                        @Param("startDate") LocalDate startDate,
                                        @Param("endDate") LocalDate endDate);
    
    /**
     * Finds recent expenses for a user.
     * 
     * @param userId The ID of the user
     * @param limit The maximum number of expenses to return
     * @return A list of recent expenses
     */
    @Query(value = "SELECT e FROM Expense e WHERE e.user.id = :userId " +
                   "ORDER BY e.date DESC, e.createdAt DESC")
    List<Expense> findRecentExpenses(@Param("userId") Long userId, Pageable pageable);
    
    /**
     * Searches expenses by description.
     * 
     * @param userId The ID of the user
     * @param searchTerm The search term
     * @return A list of matching expenses
     */
    @Query("SELECT e FROM Expense e WHERE e.user.id = :userId " +
           "AND LOWER(e.description) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<Expense> searchByDescription(@Param("userId") Long userId, @Param("searchTerm") String searchTerm);
    
    /**
     * Deletes expenses for a specific user.
     * 
     * @param userId The ID of the user
     * @return The number of expenses deleted
     */
    int deleteByUserId(Long userId);
}
