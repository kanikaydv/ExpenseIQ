package com.expenseiq.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.expenseiq.model.Notification;

/**
 * Repository interface for Notification entities.
 * 
 * This interface provides methods to interact with notification data in the database.
 */
@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    
    /**
     * Finds all notifications belonging to a user, ordered by creation date.
     * 
     * @param userId The ID of the user
     * @return A list of notifications
     */
    @Query("SELECT n FROM Notification n WHERE n.user.id = :userId ORDER BY n.createdAt DESC")
    List<Notification> findByUserIdOrderByCreatedAtDesc(@Param("userId") Long userId);
    
    /**
     * Finds a notification by ID and user ID.
     * 
     * @param id The ID of the notification
     * @param userId The ID of the user
     * @return An Optional containing the notification if found
     */
    Optional<Notification> findByIdAndUserId(Long id, Long userId);
    
    /**
     * Finds unread notifications for a user.
     * 
     * @param userId The ID of the user
     * @return A list of unread notifications
     */
    @Query("SELECT n FROM Notification n WHERE n.user.id = :userId AND n.read = false ORDER BY n.createdAt DESC")
    List<Notification> findUnreadByUserId(@Param("userId") Long userId);
    
    /**
     * Counts unread notifications for a user.
     * 
     * @param userId The ID of the user
     * @return The count of unread notifications
     */
    @Query("SELECT COUNT(n) FROM Notification n WHERE n.user.id = :userId AND n.read = false")
    long countUnreadByUserId(@Param("userId") Long userId);
    
    /**
     * Finds recent notifications for a user, ordered by creation date.
     * 
     * @param userId The ID of the user
     * @param pageable Pagination information
     * @return A list of recent notifications
     */
    @Query("SELECT n FROM Notification n WHERE n.user.id = :userId ORDER BY n.createdAt DESC")
    List<Notification> findRecentByUserId(@Param("userId") Long userId, Pageable pageable);
    
    /**
     * Marks a notification as read.
     * 
     * @param id The ID of the notification
     * @param userId The ID of the user
     * @return The number of notifications updated
     */
    @Modifying
    @Query("UPDATE Notification n SET n.read = true WHERE n.id = :id AND n.user.id = :userId")
    int markAsRead(@Param("id") Long id, @Param("userId") Long userId);
    
    /**
     * Marks all notifications as read for a user.
     * 
     * @param userId The ID of the user
     * @return The number of notifications updated
     */
    @Modifying
    @Query("UPDATE Notification n SET n.read = true WHERE n.user.id = :userId AND n.read = false")
    int markAllAsRead(@Param("userId") Long userId);
    
    /**
     * Deletes old notifications for a user.
     * 
     * @param userId The ID of the user
     * @param beforeDate The date threshold
     * @return The number of notifications deleted
     */
    @Modifying
    @Query("DELETE FROM Notification n WHERE n.user.id = :userId AND n.createdAt < :beforeDate")
    int deleteOldNotifications(@Param("userId") Long userId, @Param("beforeDate") LocalDateTime beforeDate);
    
    /**
     * Deletes all notifications for a user.
     * 
     * @param userId The ID of the user
     * @return The number of notifications deleted
     */
    int deleteByUserId(Long userId);
}
