package com.expenseiq.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.expenseiq.model.Budget;

/**
 * Repository interface for Budget entities.
 * 
 * This interface provides methods to interact with budget data in the database.
 */
@Repository
public interface BudgetRepository extends JpaRepository<Budget, Long> {
    
    /**
     * Finds all budgets belonging to a user.
     * 
     * @param userId The ID of the user
     * @return A list of budgets
     */
    List<Budget> findByUserId(Long userId);
    
    /**
     * Finds a budget by ID and user ID.
     * 
     * @param id The ID of the budget
     * @param userId The ID of the user
     * @return An Optional containing the budget if found
     */
    Optional<Budget> findByIdAndUserId(Long id, Long userId);
    
    /**
     * Finds active budgets (current date is between start and end dates).
     * 
     * @param userId The ID of the user
     * @param currentDate The current date
     * @return A list of active budgets
     */
    @Query("SELECT b FROM Budget b WHERE b.user.id = :userId " +
           "AND :currentDate BETWEEN b.startDate AND b.endDate")
    List<Budget> findActiveBudgets(@Param("userId") Long userId, 
                                   @Param("currentDate") LocalDate currentDate);
    
    /**
     * Finds active budgets for a specific category.
     * 
     * @param userId The ID of the user
     * @param categoryId The ID of the category
     * @param currentDate The current date
     * @return A list of active budgets for the category
     */
    @Query("SELECT b FROM Budget b WHERE b.user.id = :userId " +
           "AND b.category.id = :categoryId " +
           "AND :currentDate BETWEEN b.startDate AND b.endDate")
    List<Budget> findActiveBudgetsByCategory(@Param("userId") Long userId,
                                            @Param("categoryId") Long categoryId,
                                            @Param("currentDate") LocalDate currentDate);
    
    /**
     * Finds budgets that will expire soon.
     * 
     * @param userId The ID of the user
     * @param startDate The current date
     * @param endDate The date threshold for expiration
     * @return A list of budgets expiring soon
     */
    @Query("SELECT b FROM Budget b WHERE b.user.id = :userId " +
           "AND b.endDate BETWEEN :startDate AND :endDate")
    List<Budget> findBudgetsExpiringBetween(@Param("userId") Long userId,
                                           @Param("startDate") LocalDate startDate,
                                           @Param("endDate") LocalDate endDate);
    
    /**
     * Deletes budgets for a specific user.
     * 
     * @param userId The ID of the user
     * @return The number of budgets deleted
     */
    int deleteByUserId(Long userId);
}
