package com.expenseiq.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.expenseiq.model.Income;

/**
 * Repository interface for Income entities.
 * 
 * This interface provides methods to interact with income data in the database.
 */
@Repository
public interface IncomeRepository extends JpaRepository<Income, Long> {
    
    /**
     * Finds all incomes belonging to a user.
     * 
     * @param userId The ID of the user
     * @return A list of incomes
     */
    List<Income> findByUserId(Long userId);
    
    /**
     * Finds an income by ID and user ID.
     * 
     * @param id The ID of the income
     * @param userId The ID of the user
     * @return An Optional containing the income if found
     */
    Optional<Income> findByIdAndUserId(Long id, Long userId);
    
    /**
     * Finds incomes in a date range.
     * 
     * @param userId The ID of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return A list of incomes in the date range
     */
    List<Income> findByUserIdAndDateBetween(Long userId, LocalDate startDate, LocalDate endDate);
    
    /**
     * Finds incomes in a date range, paginated.
     * 
     * @param userId The ID of the user
     * @param startDate The start date
     * @param endDate The end date
     * @param pageable Pagination information
     * @return A page of incomes
     */
    Page<Income> findByUserIdAndDateBetween(Long userId, LocalDate startDate, LocalDate endDate, Pageable pageable);
    
    /**
     * Finds incomes for a specific category.
     * 
     * @param userId The ID of the user
     * @param categoryId The ID of the category
     * @return A list of incomes for the category
     */
    List<Income> findByUserIdAndCategoryId(Long userId, Long categoryId);
    
    /**
     * Finds incomes for a specific category in a date range.
     * 
     * @param userId The ID of the user
     * @param categoryId The ID of the category
     * @param startDate The start date
     * @param endDate The end date
     * @return A list of incomes for the category in the date range
     */
    List<Income> findByUserIdAndCategoryIdAndDateBetween(
            Long userId, Long categoryId, LocalDate startDate, LocalDate endDate);
    
    /**
     * Calculates the sum of incomes in a date range.
     * 
     * @param userId The ID of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return The sum of incomes, or zero if none exist
     */
    @Query("SELECT COALESCE(SUM(i.amount), 0) FROM Income i WHERE i.user.id = :userId " +
           "AND i.date BETWEEN :startDate AND :endDate")
    BigDecimal sumIncomesByDateRange(@Param("userId") Long userId,
                                    @Param("startDate") LocalDate startDate,
                                    @Param("endDate") LocalDate endDate);
    
    /**
     * Calculates the sum of incomes for a specific category in a date range.
     * 
     * @param userId The ID of the user
     * @param categoryId The ID of the category
     * @param startDate The start date
     * @param endDate The end date
     * @return The sum of incomes, or zero if none exist
     */
    @Query("SELECT COALESCE(SUM(i.amount), 0) FROM Income i WHERE i.user.id = :userId " +
           "AND i.category.id = :categoryId AND i.date BETWEEN :startDate AND :endDate")
    BigDecimal sumIncomesByCategoryAndDateRange(@Param("userId") Long userId,
                                             @Param("categoryId") Long categoryId,
                                             @Param("startDate") LocalDate startDate,
                                             @Param("endDate") LocalDate endDate);
    
    /**
     * Aggregates incomes by category for a date range.
     * 
     * @param userId The ID of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return A list of category name and sum pairs
     */
    @Query("SELECT c.name, COALESCE(SUM(i.amount), 0) FROM Income i " +
           "JOIN i.category c WHERE i.user.id = :userId " +
           "AND i.date BETWEEN :startDate AND :endDate " +
           "GROUP BY c.name ORDER BY SUM(i.amount) DESC")
    List<Object[]> sumIncomesByCategory(@Param("userId") Long userId,
                                       @Param("startDate") LocalDate startDate,
                                       @Param("endDate") LocalDate endDate);
    
    /**
     * Finds recent incomes for a user.
     * 
     * @param userId The ID of the user
     * @param limit The maximum number of incomes to return
     * @return A list of recent incomes
     */
    @Query(value = "SELECT i FROM Income i WHERE i.user.id = :userId " +
                   "ORDER BY i.date DESC, i.createdAt DESC")
    List<Income> findRecentIncomes(@Param("userId") Long userId, Pageable pageable);
    
    /**
     * Searches incomes by description.
     * 
     * @param userId The ID of the user
     * @param searchTerm The search term
     * @return A list of matching incomes
     */
    @Query("SELECT i FROM Income i WHERE i.user.id = :userId " +
           "AND LOWER(i.description) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<Income> searchByDescription(@Param("userId") Long userId, @Param("searchTerm") String searchTerm);
    
    /**
     * Deletes incomes for a specific user.
     * 
     * @param userId The ID of the user
     * @return The number of incomes deleted
     */
    int deleteByUserId(Long userId);
}
