package com.expenseiq.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.expenseiq.model.User;

/**
 * Repository interface for User entities.
 * 
 * This interface provides methods to interact with user data in the database.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    /**
     * Finds a user by email.
     * 
     * @param email The email of the user
     * @return An Optional containing the user if found
     */
    Optional<User> findByEmail(String email);
    
    /**
     * Checks if a user with the given email exists.
     * 
     * @param email The email to check
     * @return true if a user with the email exists, false otherwise
     */
    boolean existsByEmail(String email);
    
    /**
     * Updates a user's password.
     * 
     * @param userId The ID of the user
     * @param newPassword The new password (already encrypted)
     * @return The number of users updated
     */
    @Modifying
    @Query("UPDATE User u SET u.password = :newPassword WHERE u.id = :userId")
    int updatePassword(@Param("userId") Long userId, @Param("newPassword") String newPassword);
    
    /**
     * Updates a user's last login date.
     * 
     * @param email The email of the user
     * @return The number of users updated
     */
    @Modifying
    @Query("UPDATE User u SET u.lastLoginDate = CURRENT_TIMESTAMP WHERE u.email = :email")
    int updateLastLoginDate(@Param("email") String email);
    
    /**
     * Updates a user's active status.
     * 
     * @param userId The ID of the user
     * @param active The new active status
     * @return The number of users updated
     */
    @Modifying
    @Query("UPDATE User u SET u.active = :active WHERE u.id = :userId")
    int updateActiveStatus(@Param("userId") Long userId, @Param("active") boolean active);
    
    /**
     * Finds a user by email and active status.
     * 
     * @param email The email of the user
     * @param active The active status
     * @return An Optional containing the user if found
     */
    Optional<User> findByEmailAndActive(String email, boolean active);
}
