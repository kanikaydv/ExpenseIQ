package com.expenseiq.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.expenseiq.model.Category;

/**
 * Repository interface for Category entities.
 * 
 * This interface provides methods to interact with category data in the database.
 */
@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {
    
    /**
     * Finds all categories belonging to a user or that are system defaults.
     * 
     * @param userId The ID of the user
     * @return A list of categories
     */
    @Query("SELECT c FROM Category c WHERE c.user.id = ?1 OR c.user IS NULL")
    List<Category> findAllByUserIdOrSystemDefault(Long userId);
    
    /**
     * Finds all expense categories.
     * 
     * @return A list of expense categories
     */
    List<Category> findByType(String type);
    
    /**
     * Finds all expense categories for a user or that are system defaults.
     * 
     * @param userId The ID of the user
     * @return A list of expense categories
     */
    @Query("SELECT c FROM Category c WHERE (c.user.id = ?1 OR c.user IS NULL) AND c.type = 'EXPENSE'")
    List<Category> findExpenseCategoriesByUserIdOrSystemDefault(Long userId);
    
    /**
     * Finds all income categories for a user or that are system defaults.
     * 
     * @param userId The ID of the user
     * @return A list of income categories
     */
    @Query("SELECT c FROM Category c WHERE (c.user.id = ?1 OR c.user IS NULL) AND c.type = 'INCOME'")
    List<Category> findIncomeCategoriesByUserIdOrSystemDefault(Long userId);
    
    /**
     * Finds a category by ID and user ID, or system default categories.
     * 
     * @param id The ID of the category
     * @param userId The ID of the user
     * @return An Optional containing the category if found
     */
    @Query("SELECT c FROM Category c WHERE c.id = ?1 AND (c.user.id = ?2 OR c.user IS NULL)")
    Optional<Category> findByIdAndUserIdOrSystemDefault(Long id, Long userId);
    
    /**
     * Finds a category by name and user ID.
     * 
     * @param name The name of the category
     * @param userId The ID of the user
     * @return An Optional containing the category if found
     */
    Optional<Category> findByNameAndUserId(String name, Long userId);
    
    /**
     * Checks if a category with the given name exists for the user.
     * 
     * @param name The name of the category
     * @param userId The ID of the user
     * @return true if the category exists, false otherwise
     */
    boolean existsByNameAndUserId(String name, Long userId);
    
    /**
     * Deletes custom categories for a specific user.
     * 
     * @param userId The ID of the user
     * @return The number of categories deleted
     */
    int deleteByUserId(Long userId);
}
