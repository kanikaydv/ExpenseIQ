package com.expenseiq.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.expenseiq.dto.BudgetDTO;
import com.expenseiq.dto.CategoryDTO;
import com.expenseiq.service.BudgetService;
import com.expenseiq.service.CategoryService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller for managing budget-related operations.
 * 
 * This controller handles creating, retrieving, updating, and deleting budgets.
 */
@Controller
@RequestMapping("/budget")
@RequiredArgsConstructor
@Slf4j
public class BudgetController {

    private final BudgetService budgetService;
    private final CategoryService categoryService;

    /**
     * Lists all budgets for the current user.
     * 
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the budget list view
     */
    @GetMapping
    public String listBudgets(Model model, Principal principal) {
        log.info("Listing budgets for user: {}", principal.getName());
        List<BudgetDTO> budgets = budgetService.getBudgetsByUser(principal.getName());
        model.addAttribute("budgets", budgets);
        return "budget/list";
    }

    /**
     * Displays the budget creation form.
     * 
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the budget creation view
     */
    @GetMapping("/create")
    public String showCreateForm(Model model, Principal principal) {
        log.info("Showing budget creation form for user: {}", principal.getName());
        model.addAttribute("budget", new BudgetDTO());
        
        // Get categories for dropdown selection
        List<CategoryDTO> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        
        return "budget/create";
    }

    /**
     * Processes budget creation.
     * 
     * @param budgetDTO The budget data transfer object
     * @param result The binding result for validation
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to budget list on success, or back to creation form on error
     */
    @PostMapping("/create")
    public String createBudget(@Valid @ModelAttribute("budget") BudgetDTO budgetDTO,
                               BindingResult result,
                               Principal principal,
                               RedirectAttributes redirectAttributes) {
        log.info("Processing budget creation for user: {}", principal.getName());
        
        if (result.hasErrors()) {
            log.warn("Validation errors during budget creation: {}", result.getAllErrors());
            return "budget/create";
        }
        
        try {
            budgetService.createBudget(budgetDTO, principal.getName());
            log.info("Successfully created budget for user: {}", principal.getName());
            redirectAttributes.addFlashAttribute("success", "Budget created successfully.");
            return "redirect:/budget";
        } catch (Exception e) {
            log.error("Error creating budget", e);
            redirectAttributes.addFlashAttribute("error", "Failed to create budget: " + e.getMessage());
            return "redirect:/budget/create";
        }
    }

    /**
     * Displays the budget edit form.
     * 
     * @param id The ID of the budget to edit
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the budget edit view
     */
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, Principal principal) {
        log.info("Showing edit form for budget ID: {}", id);
        BudgetDTO budget = budgetService.getBudgetById(id, principal.getName());
        model.addAttribute("budget", budget);
        
        // Get categories for dropdown selection
        List<CategoryDTO> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        
        return "budget/create"; // Reusing the create form for editing
    }

    /**
     * Processes budget updates.
     * 
     * @param id The ID of the budget to update
     * @param budgetDTO The updated budget data
     * @param result The binding result for validation
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to budget list on success, or back to edit form on error
     */
    @PostMapping("/edit/{id}")
    public String updateBudget(@PathVariable Long id,
                               @Valid @ModelAttribute("budget") BudgetDTO budgetDTO,
                               BindingResult result,
                               Principal principal,
                               RedirectAttributes redirectAttributes) {
        log.info("Processing budget update for ID: {}", id);
        
        if (result.hasErrors()) {
            log.warn("Validation errors during budget update: {}", result.getAllErrors());
            return "budget/create";
        }
        
        try {
            budgetDTO.setId(id);
            budgetService.updateBudget(budgetDTO, principal.getName());
            log.info("Successfully updated budget ID: {}", id);
            redirectAttributes.addFlashAttribute("success", "Budget updated successfully.");
            return "redirect:/budget";
        } catch (Exception e) {
            log.error("Error updating budget", e);
            redirectAttributes.addFlashAttribute("error", "Failed to update budget: " + e.getMessage());
            return "redirect:/budget/edit/" + id;
        }
    }

    /**
     * Deletes a budget.
     * 
     * @param id The ID of the budget to delete
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to budget list
     */
    @GetMapping("/delete/{id}")
    public String deleteBudget(@PathVariable Long id,
                               Principal principal,
                               RedirectAttributes redirectAttributes) {
        log.info("Deleting budget ID: {}", id);
        
        try {
            budgetService.deleteBudget(id, principal.getName());
            log.info("Successfully deleted budget ID: {}", id);
            redirectAttributes.addFlashAttribute("success", "Budget deleted successfully.");
        } catch (Exception e) {
            log.error("Error deleting budget", e);
            redirectAttributes.addFlashAttribute("error", "Failed to delete budget: " + e.getMessage());
        }
        
        return "redirect:/budget";
    }
}
