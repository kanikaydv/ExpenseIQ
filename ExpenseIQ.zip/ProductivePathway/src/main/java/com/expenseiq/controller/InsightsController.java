package com.expenseiq.controller;

import java.security.Principal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.expenseiq.service.InsightService;
import com.expenseiq.service.InvestmentService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller for handling financial insights and investment suggestions.
 * 
 * This controller provides endpoints for viewing financial insights,
 * spending trends, and investment recommendations.
 */
@Controller
@RequestMapping("/insights")
@RequiredArgsConstructor
@Slf4j
public class InsightsController {

    private final InsightService insightService;
    private final InvestmentService investmentService;

    /**
     * Displays financial insights and investment suggestions.
     * 
     * @param period The time period to display data for (month, quarter, year)
     * @param date The specific date to show data for
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the insights view
     */
    @GetMapping
    public String showInsights(
            @RequestParam(required = false, defaultValue = "month") String period,
            @RequestParam(required = false) String date,
            Model model,
            Principal principal) {
        
        log.info("Showing insights for user: {} with period: {}", principal.getName(), period);
        
        // Parse date or use current date
        LocalDate selectedDate;
        if (date != null && !date.isEmpty()) {
            selectedDate = LocalDate.parse(date, DateTimeFormatter.ISO_DATE);
        } else {
            selectedDate = LocalDate.now();
        }
        
        // Get spending trends
        model.addAttribute("spendingTrends", 
                insightService.getSpendingTrends(principal.getName(), period, selectedDate));
        
        // Get savings tips
        model.addAttribute("savingsTips", 
                insightService.getSavingsTips(principal.getName()));
        
        // Get investment suggestions
        model.addAttribute("investmentSuggestions", 
                investmentService.getInvestmentSuggestions(principal.getName()));
        
        // Get expense predictions
        model.addAttribute("expensePredictions", 
                insightService.getPredictedExpenses(principal.getName(), period, selectedDate));
        
        // Add period and date information to model
        model.addAttribute("period", period);
        model.addAttribute("selectedDate", selectedDate);
        
        // Format the date for display
        DateTimeFormatter formatter;
        if ("month".equals(period)) {
            formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
        } else if ("quarter".equals(period)) {
            formatter = DateTimeFormatter.ofPattern("QQQ yyyy");
        } else {
            formatter = DateTimeFormatter.ofPattern("yyyy");
        }
        model.addAttribute("formattedDate", selectedDate.format(formatter));
        
        return "insights/index";
    }
}
