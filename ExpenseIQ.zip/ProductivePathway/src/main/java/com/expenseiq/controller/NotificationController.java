package com.expenseiq.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.expenseiq.dto.NotificationDTO;
import com.expenseiq.service.NotificationService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller for handling notification-related operations.
 * 
 * This controller manages listing and marking notifications as read.
 */
@Controller
@RequestMapping("/notifications")
@RequiredArgsConstructor
@Slf4j
public class NotificationController {

    private final NotificationService notificationService;

    /**
     * Lists all notifications for the current user.
     * 
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the notifications list view
     */
    @GetMapping
    public String listNotifications(Model model, Principal principal) {
        log.info("Listing notifications for user: {}", principal.getName());
        List<NotificationDTO> notifications = notificationService.getNotificationsByUser(principal.getName());
        model.addAttribute("notifications", notifications);
        return "notifications/list";
    }

    /**
     * Marks a notification as read.
     * 
     * @param id The ID of the notification to mark as read
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to notifications list
     */
    @GetMapping("/read/{id}")
    public String markAsRead(@PathVariable Long id,
                             Principal principal,
                             RedirectAttributes redirectAttributes) {
        log.info("Marking notification ID: {} as read for user: {}", id, principal.getName());
        
        try {
            notificationService.markAsRead(id, principal.getName());
            log.info("Successfully marked notification ID: {} as read", id);
            redirectAttributes.addFlashAttribute("success", "Notification marked as read.");
        } catch (Exception e) {
            log.error("Error marking notification as read", e);
            redirectAttributes.addFlashAttribute("error", "Failed to mark notification as read: " + e.getMessage());
        }
        
        return "redirect:/notifications";
    }

    /**
     * Marks all notifications as read.
     * 
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to notifications list
     */
    @GetMapping("/read-all")
    public String markAllAsRead(Principal principal,
                                RedirectAttributes redirectAttributes) {
        log.info("Marking all notifications as read for user: {}", principal.getName());
        
        try {
            notificationService.markAllAsRead(principal.getName());
            log.info("Successfully marked all notifications as read for user: {}", principal.getName());
            redirectAttributes.addFlashAttribute("success", "All notifications marked as read.");
        } catch (Exception e) {
            log.error("Error marking all notifications as read", e);
            redirectAttributes.addFlashAttribute("error", "Failed to mark all notifications as read: " + e.getMessage());
        }
        
        return "redirect:/notifications";
    }

    /**
     * Deletes a notification.
     * 
     * @param id The ID of the notification to delete
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to notifications list
     */
    @GetMapping("/delete/{id}")
    public String deleteNotification(@PathVariable Long id,
                                    Principal principal,
                                    RedirectAttributes redirectAttributes) {
        log.info("Deleting notification ID: {} for user: {}", id, principal.getName());
        
        try {
            notificationService.deleteNotification(id, principal.getName());
            log.info("Successfully deleted notification ID: {}", id);
            redirectAttributes.addFlashAttribute("success", "Notification deleted successfully.");
        } catch (Exception e) {
            log.error("Error deleting notification", e);
            redirectAttributes.addFlashAttribute("error", "Failed to delete notification: " + e.getMessage());
        }
        
        return "redirect:/notifications";
    }
}
