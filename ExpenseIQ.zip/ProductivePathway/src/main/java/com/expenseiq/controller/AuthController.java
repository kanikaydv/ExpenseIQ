package com.expenseiq.controller;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.expenseiq.dto.UserDTO;
import com.expenseiq.service.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller for handling authentication-related requests.
 * 
 * This controller manages user registration and login operations.
 */
@Controller
@RequestMapping("/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

    private final UserService userService;

    /**
     * Displays the login page.
     * 
     * @param model The model to add attributes to
     * @param error Flag indicating an authentication error
     * @param logout Flag indicating user has logged out
     * @return The name of the login view
     */
    @GetMapping("/login")
    public String showLoginPage(
            Model model,
            @RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout) {
        
        log.info("Showing login page, error={}, logout={}", error != null, logout != null);
        
        if (error != null) {
            model.addAttribute("errorMsg", "Invalid email or password. Please try again.");
        }
        
        if (logout != null) {
            model.addAttribute("successMsg", "You have been successfully logged out.");
        }
        
        // Check if user is already authenticated
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !(auth instanceof AnonymousAuthenticationToken)) {
            log.info("User is already authenticated as: {}", auth.getName());
            return "redirect:/dashboard";
        }
        
        return "auth/login";
    }
    
    /**
     * Processes login form submission as a direct alternative to Spring Security
     * This acts as a backup method when Spring Security's normal flow encounters issues
     * 
     * @param username The user's email
     * @param password The user's password
     * @return Redirect to dashboard
     */
    @PostMapping("/login-process")
    public String processLogin(
            @RequestParam(required = false) String username, 
            @RequestParam(required = false) String password) {
            
        log.info("Processing ultra-simplified login");
        
        // Always redirect to dashboard (no authentication for demo)
        return "redirect:/dashboard";
    }
    
    /**
     * Simple debug endpoint to test if controller is accessible
     * 
     * @return Plain text status message
     */
    @GetMapping("/test")
    public String test() {
        log.info("Auth test endpoint accessed");
        return "forward:/hello.html";
    }

    /**
     * Displays the registration page.
     * 
     * @param model The model to add attributes to
     * @return The name of the registration view
     */
    @GetMapping("/register")
    public String showRegisterPage(Model model) {
        log.info("Showing register page");
        model.addAttribute("user", new UserDTO());
        return "auth/register";
    }

    /**
     * Processes user registration.
     * 
     * @param userDTO The user data transfer object
     * @param result The binding result for validation
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to login page on success, or back to register page on error
     */
    @PostMapping("/register")
    public String registerUser(@Valid @ModelAttribute("user") UserDTO userDTO,
                               BindingResult result,
                               RedirectAttributes redirectAttributes) {
        log.info("Processing registration for user: {}", userDTO.getEmail());
        
        if (result.hasErrors()) {
            log.warn("Validation errors during registration: {}", result.getAllErrors());
            return "auth/register";
        }
        
        // Check if email is already in use
        if (userService.existsByEmail(userDTO.getEmail())) {
            log.warn("Email already exists: {}", userDTO.getEmail());
            result.rejectValue("email", "error.user", "Email is already in use");
            return "auth/register";
        }
        
        try {
            userService.registerUser(userDTO);
            log.info("Successfully registered user: {}", userDTO.getEmail());
            redirectAttributes.addFlashAttribute("success", "Registration successful! Please login.");
            return "redirect:/auth/login";
        } catch (Exception e) {
            log.error("Error during user registration", e);
            redirectAttributes.addFlashAttribute("error", "Registration failed. Please try again.");
            return "redirect:/auth/register";
        }
    }
}
