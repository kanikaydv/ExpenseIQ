package com.expenseiq.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.expenseiq.dto.CategoryDTO;
import com.expenseiq.dto.ExpenseDTO;
import com.expenseiq.service.CategoryService;
import com.expenseiq.service.CsvImportService;
import com.expenseiq.service.ExpenseService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller for handling expense-related operations.
 * 
 * This controller manages creating, retrieving, updating, and deleting expenses,
 * as well as importing expenses from CSV files.
 */
@Controller
@RequestMapping("/expenses")
@RequiredArgsConstructor
@Slf4j
public class ExpenseController {

    private final ExpenseService expenseService;
    private final CategoryService categoryService;
    private final CsvImportService csvImportService;

    /**
     * Lists all expenses for the current user.
     * 
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the expense list view
     */
    @GetMapping
    public String listExpenses(Model model, Principal principal) {
        log.info("Listing expenses for user: {}", principal.getName());
        List<ExpenseDTO> expenses = expenseService.getExpensesByUser(principal.getName());
        model.addAttribute("expenses", expenses);
        return "expense/list";
    }

    /**
     * Displays the expense creation form.
     * 
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the expense creation view
     */
    @GetMapping("/create")
    public String showCreateForm(Model model, Principal principal) {
        log.info("Showing expense creation form for user: {}", principal.getName());
        model.addAttribute("expense", new ExpenseDTO());
        
        // Get categories for dropdown selection
        List<CategoryDTO> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        
        return "expense/create";
    }

    /**
     * Processes expense creation.
     * 
     * @param expenseDTO The expense data transfer object
     * @param result The binding result for validation
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to expense list on success, or back to creation form on error
     */
    @PostMapping("/create")
    public String createExpense(@Valid @ModelAttribute("expense") ExpenseDTO expenseDTO,
                                BindingResult result,
                                Principal principal,
                                RedirectAttributes redirectAttributes) {
        log.info("Processing expense creation for user: {}", principal.getName());
        
        if (result.hasErrors()) {
            log.warn("Validation errors during expense creation: {}", result.getAllErrors());
            return "expense/create";
        }
        
        try {
            expenseService.createExpense(expenseDTO, principal.getName());
            log.info("Successfully created expense for user: {}", principal.getName());
            redirectAttributes.addFlashAttribute("success", "Expense created successfully.");
            return "redirect:/expenses";
        } catch (Exception e) {
            log.error("Error creating expense", e);
            redirectAttributes.addFlashAttribute("error", "Failed to create expense: " + e.getMessage());
            return "redirect:/expenses/create";
        }
    }

    /**
     * Displays the expense edit form.
     * 
     * @param id The ID of the expense to edit
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the expense edit view
     */
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, Principal principal) {
        log.info("Showing edit form for expense ID: {}", id);
        ExpenseDTO expense = expenseService.getExpenseById(id, principal.getName());
        model.addAttribute("expense", expense);
        
        // Get categories for dropdown selection
        List<CategoryDTO> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        
        return "expense/create"; // Reusing the create form for editing
    }

    /**
     * Processes expense updates.
     * 
     * @param id The ID of the expense to update
     * @param expenseDTO The updated expense data
     * @param result The binding result for validation
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to expense list on success, or back to edit form on error
     */
    @PostMapping("/edit/{id}")
    public String updateExpense(@PathVariable Long id,
                                @Valid @ModelAttribute("expense") ExpenseDTO expenseDTO,
                                BindingResult result,
                                Principal principal,
                                RedirectAttributes redirectAttributes) {
        log.info("Processing expense update for ID: {}", id);
        
        if (result.hasErrors()) {
            log.warn("Validation errors during expense update: {}", result.getAllErrors());
            return "expense/create";
        }
        
        try {
            expenseDTO.setId(id);
            expenseService.updateExpense(expenseDTO, principal.getName());
            log.info("Successfully updated expense ID: {}", id);
            redirectAttributes.addFlashAttribute("success", "Expense updated successfully.");
            return "redirect:/expenses";
        } catch (Exception e) {
            log.error("Error updating expense", e);
            redirectAttributes.addFlashAttribute("error", "Failed to update expense: " + e.getMessage());
            return "redirect:/expenses/edit/" + id;
        }
    }

    /**
     * Deletes an expense.
     * 
     * @param id The ID of the expense to delete
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to expense list
     */
    @GetMapping("/delete/{id}")
    public String deleteExpense(@PathVariable Long id,
                                Principal principal,
                                RedirectAttributes redirectAttributes) {
        log.info("Deleting expense ID: {}", id);
        
        try {
            expenseService.deleteExpense(id, principal.getName());
            log.info("Successfully deleted expense ID: {}", id);
            redirectAttributes.addFlashAttribute("success", "Expense deleted successfully.");
        } catch (Exception e) {
            log.error("Error deleting expense", e);
            redirectAttributes.addFlashAttribute("error", "Failed to delete expense: " + e.getMessage());
        }
        
        return "redirect:/expenses";
    }

    /**
     * Displays the CSV import form.
     * 
     * @param model The model to add attributes to
     * @return The name of the CSV import view
     */
    @GetMapping("/import")
    public String showImportForm(Model model) {
        log.info("Showing CSV import form");
        return "expense/import";
    }

    /**
     * Processes CSV file import for expenses.
     * 
     * @param file The uploaded CSV file
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to expense list
     */
    @PostMapping("/import")
    public String importCsv(@RequestParam("file") MultipartFile file,
                            Principal principal,
                            RedirectAttributes redirectAttributes) {
        log.info("Processing CSV import for user: {}", principal.getName());
        
        if (file.isEmpty()) {
            log.warn("Empty file uploaded during CSV import");
            redirectAttributes.addFlashAttribute("error", "Please select a file to upload");
            return "redirect:/expenses/import";
        }
        
        try {
            int count = csvImportService.importExpensesFromCSV(file, principal.getName());
            log.info("Successfully imported {} expenses from CSV for user: {}", count, principal.getName());
            redirectAttributes.addFlashAttribute("success", "Successfully imported " + count + " expenses.");
            return "redirect:/expenses";
        } catch (Exception e) {
            log.error("Error importing expenses from CSV", e);
            redirectAttributes.addFlashAttribute("error", "Failed to import expenses: " + e.getMessage());
            return "redirect:/expenses/import";
        }
    }
}
