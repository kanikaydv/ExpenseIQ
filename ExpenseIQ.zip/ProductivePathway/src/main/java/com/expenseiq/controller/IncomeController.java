package com.expenseiq.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.expenseiq.dto.CategoryDTO;
import com.expenseiq.dto.IncomeDTO;
import com.expenseiq.service.CategoryService;
import com.expenseiq.service.CsvImportService;
import com.expenseiq.service.IncomeService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller for handling income-related operations.
 * 
 * This controller manages creating, retrieving, updating, and deleting incomes,
 * as well as importing incomes from CSV files.
 */
@Controller
@RequestMapping("/incomes")
@RequiredArgsConstructor
@Slf4j
public class IncomeController {

    private final IncomeService incomeService;
    private final CategoryService categoryService;
    private final CsvImportService csvImportService;

    /**
     * Lists all incomes for the current user.
     * 
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the income list view
     */
    @GetMapping
    public String listIncomes(Model model, Principal principal) {
        log.info("Listing incomes for user: {}", principal.getName());
        List<IncomeDTO> incomes = incomeService.getIncomesByUser(principal.getName());
        model.addAttribute("incomes", incomes);
        return "income/list";
    }

    /**
     * Displays the income creation form.
     * 
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the income creation view
     */
    @GetMapping("/create")
    public String showCreateForm(Model model, Principal principal) {
        log.info("Showing income creation form for user: {}", principal.getName());
        model.addAttribute("income", new IncomeDTO());
        
        // Get categories for dropdown selection
        List<CategoryDTO> categories = categoryService.getIncomeCategories();
        model.addAttribute("categories", categories);
        
        return "income/create";
    }

    /**
     * Processes income creation.
     * 
     * @param incomeDTO The income data transfer object
     * @param result The binding result for validation
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to income list on success, or back to creation form on error
     */
    @PostMapping("/create")
    public String createIncome(@Valid @ModelAttribute("income") IncomeDTO incomeDTO,
                              BindingResult result,
                              Principal principal,
                              RedirectAttributes redirectAttributes) {
        log.info("Processing income creation for user: {}", principal.getName());
        
        if (result.hasErrors()) {
            log.warn("Validation errors during income creation: {}", result.getAllErrors());
            return "income/create";
        }
        
        try {
            incomeService.createIncome(incomeDTO, principal.getName());
            log.info("Successfully created income for user: {}", principal.getName());
            redirectAttributes.addFlashAttribute("success", "Income created successfully.");
            return "redirect:/incomes";
        } catch (Exception e) {
            log.error("Error creating income", e);
            redirectAttributes.addFlashAttribute("error", "Failed to create income: " + e.getMessage());
            return "redirect:/incomes/create";
        }
    }

    /**
     * Displays the income edit form.
     * 
     * @param id The ID of the income to edit
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the income edit view
     */
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, Principal principal) {
        log.info("Showing edit form for income ID: {}", id);
        IncomeDTO income = incomeService.getIncomeById(id, principal.getName());
        model.addAttribute("income", income);
        
        // Get categories for dropdown selection
        List<CategoryDTO> categories = categoryService.getIncomeCategories();
        model.addAttribute("categories", categories);
        
        return "income/create"; // Reusing the create form for editing
    }

    /**
     * Processes income updates.
     * 
     * @param id The ID of the income to update
     * @param incomeDTO The updated income data
     * @param result The binding result for validation
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to income list on success, or back to edit form on error
     */
    @PostMapping("/edit/{id}")
    public String updateIncome(@PathVariable Long id,
                              @Valid @ModelAttribute("income") IncomeDTO incomeDTO,
                              BindingResult result,
                              Principal principal,
                              RedirectAttributes redirectAttributes) {
        log.info("Processing income update for ID: {}", id);
        
        if (result.hasErrors()) {
            log.warn("Validation errors during income update: {}", result.getAllErrors());
            return "income/create";
        }
        
        try {
            incomeDTO.setId(id);
            incomeService.updateIncome(incomeDTO, principal.getName());
            log.info("Successfully updated income ID: {}", id);
            redirectAttributes.addFlashAttribute("success", "Income updated successfully.");
            return "redirect:/incomes";
        } catch (Exception e) {
            log.error("Error updating income", e);
            redirectAttributes.addFlashAttribute("error", "Failed to update income: " + e.getMessage());
            return "redirect:/incomes/edit/" + id;
        }
    }

    /**
     * Deletes an income.
     * 
     * @param id The ID of the income to delete
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to income list
     */
    @GetMapping("/delete/{id}")
    public String deleteIncome(@PathVariable Long id,
                              Principal principal,
                              RedirectAttributes redirectAttributes) {
        log.info("Deleting income ID: {}", id);
        
        try {
            incomeService.deleteIncome(id, principal.getName());
            log.info("Successfully deleted income ID: {}", id);
            redirectAttributes.addFlashAttribute("success", "Income deleted successfully.");
        } catch (Exception e) {
            log.error("Error deleting income", e);
            redirectAttributes.addFlashAttribute("error", "Failed to delete income: " + e.getMessage());
        }
        
        return "redirect:/incomes";
    }

    /**
     * Displays the CSV import form for incomes.
     * 
     * @param model The model to add attributes to
     * @return The name of the CSV import view
     */
    @GetMapping("/import")
    public String showImportForm(Model model) {
        log.info("Showing CSV import form for incomes");
        return "income/import";
    }

    /**
     * Processes CSV file import for incomes.
     * 
     * @param file The uploaded CSV file
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to income list
     */
    @PostMapping("/import")
    public String importCsv(@RequestParam("file") MultipartFile file,
                            Principal principal,
                            RedirectAttributes redirectAttributes) {
        log.info("Processing income CSV import for user: {}", principal.getName());
        
        if (file.isEmpty()) {
            log.warn("Empty file uploaded during income CSV import");
            redirectAttributes.addFlashAttribute("error", "Please select a file to upload");
            return "redirect:/incomes/import";
        }
        
        try {
            int count = csvImportService.importIncomesFromCSV(file, principal.getName());
            log.info("Successfully imported {} incomes from CSV for user: {}", count, principal.getName());
            redirectAttributes.addFlashAttribute("success", "Successfully imported " + count + " incomes.");
            return "redirect:/incomes";
        } catch (Exception e) {
            log.error("Error importing incomes from CSV", e);
            redirectAttributes.addFlashAttribute("error", "Failed to import incomes: " + e.getMessage());
            return "redirect:/incomes/import";
        }
    }
}
