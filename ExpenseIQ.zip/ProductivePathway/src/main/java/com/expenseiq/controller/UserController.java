package com.expenseiq.controller;

import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.expenseiq.dto.UserDTO;
import com.expenseiq.service.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller for handling user profile operations.
 * 
 * This controller manages viewing and updating user profile information.
 */
@Controller
@RequestMapping("/user")
@RequiredArgsConstructor
@Slf4j
public class UserController {

    private final UserService userService;

    /**
     * Displays the user profile page.
     * 
     * @param model The model to add attributes to
     * @param principal The authenticated user
     * @return The name of the profile view
     */
    @GetMapping("/profile")
    public String viewProfile(Model model, Principal principal) {
        log.info("Showing profile for user: {}", principal.getName());
        
        UserDTO user = userService.getUserByEmail(principal.getName());
        model.addAttribute("user", user);
        
        return "user/profile";
    }

    /**
     * Processes user profile updates.
     * 
     * @param userDTO The updated user data
     * @param result The binding result for validation
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to profile page
     */
    @PostMapping("/profile")
    public String updateProfile(@Valid @ModelAttribute("user") UserDTO userDTO,
                                BindingResult result,
                                Principal principal,
                                RedirectAttributes redirectAttributes) {
        log.info("Processing profile update for user: {}", principal.getName());
        
        if (result.hasErrors()) {
            log.warn("Validation errors during profile update: {}", result.getAllErrors());
            return "user/profile";
        }
        
        // Ensure we're updating the correct user
        userDTO.setEmail(principal.getName());
        
        try {
            userService.updateUser(userDTO);
            log.info("Successfully updated profile for user: {}", principal.getName());
            redirectAttributes.addFlashAttribute("success", "Profile updated successfully.");
        } catch (Exception e) {
            log.error("Error updating user profile", e);
            redirectAttributes.addFlashAttribute("error", "Failed to update profile: " + e.getMessage());
        }
        
        return "redirect:/user/profile";
    }

    /**
     * Displays the change password form.
     * 
     * @param model The model to add attributes to
     * @return The name of the change password view
     */
    @GetMapping("/change-password")
    public String showChangePasswordForm(Model model) {
        log.info("Showing change password form");
        model.addAttribute("passwordChangeRequest", new Object()); // Empty form object
        return "user/change-password";
    }

    /**
     * Processes password changes.
     * 
     * @param currentPassword The user's current password
     * @param newPassword The new password
     * @param confirmPassword Confirmation of the new password
     * @param principal The authenticated user
     * @param redirectAttributes The redirect attributes for flash messages
     * @return Redirect to profile page on success, or back to change password form on error
     */
    @PostMapping("/change-password")
    public String changePassword(
            @ModelAttribute("currentPassword") String currentPassword,
            @ModelAttribute("newPassword") String newPassword,
            @ModelAttribute("confirmPassword") String confirmPassword,
            Principal principal,
            RedirectAttributes redirectAttributes) {
        
        log.info("Processing password change for user: {}", principal.getName());
        
        // Validate passwords match
        if (!newPassword.equals(confirmPassword)) {
            log.warn("New passwords don't match during password change");
            redirectAttributes.addFlashAttribute("error", "New passwords don't match");
            return "redirect:/user/change-password";
        }
        
        try {
            boolean success = userService.changePassword(principal.getName(), currentPassword, newPassword);
            
            if (success) {
                log.info("Successfully changed password for user: {}", principal.getName());
                redirectAttributes.addFlashAttribute("success", "Password changed successfully.");
                return "redirect:/user/profile";
            } else {
                log.warn("Current password incorrect during password change for user: {}", principal.getName());
                redirectAttributes.addFlashAttribute("error", "Current password is incorrect");
                return "redirect:/user/change-password";
            }
        } catch (Exception e) {
            log.error("Error changing password", e);
            redirectAttributes.addFlashAttribute("error", "Failed to change password: " + e.getMessage());
            return "redirect:/user/change-password";
        }
    }
}
