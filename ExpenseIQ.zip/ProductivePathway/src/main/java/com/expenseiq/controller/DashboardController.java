package com.expenseiq.controller;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.expenseiq.dto.DashboardDTO;
import com.expenseiq.service.DashboardService;
import com.expenseiq.service.InsightService;
import com.expenseiq.service.NotificationService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Controller for handling dashboard-related requests.
 * 
 * This controller provides endpoints for viewing the main dashboard
 * with financial summaries, charts, and insights.
 */
@Controller
@RequestMapping("/dashboard")
@RequiredArgsConstructor
@Slf4j
public class DashboardController {

    private final DashboardService dashboardService;
    private final InsightService insightService;
    private final NotificationService notificationService;

    /**
     * Simplified dashboard access - uses debug mode for demo purposes
     * This allows access to the dashboard without requiring authentication
     * 
     * @param model The model to add attributes to
     * @return The name of the dashboard view
     */
    @GetMapping
    public String showDashboard(Model model) {
        log.info("Showing simplified dashboard with sample data (no authentication required)");
        return debugDashboard(model);
    }
    
    /**
     * Special debug endpoint - access dashboard regardless of authentication
     * This is for testing and troubleshooting only.
     * 
     * @param model The model to add attributes to
     * @return The name of the dashboard view
     */
    @GetMapping("/debug")
    public String debugDashboard(Model model) {
        log.info("Accessing dashboard debug mode with sample data");
        
        // Add minimal attributes to model to avoid service dependencies
        model.addAttribute("period", "month");
        model.addAttribute("selectedDate", LocalDate.now());
        model.addAttribute("formattedDate", LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM yyyy")));
        model.addAttribute("debugMode", true);
        model.addAttribute("username", "debug@example.com");
        
        // Create empty lists for dependencies
        model.addAttribute("insights", new ArrayList<>());
        model.addAttribute("notifications", new ArrayList<>());
        
        // Create a minimal dashboard DTO with test data
        DashboardDTO dashboardDTO = new DashboardDTO();
        dashboardDTO.setTotalIncome(new BigDecimal("5200.00"));
        dashboardDTO.setTotalExpenses(new BigDecimal("3400.00"));
        dashboardDTO.setNetSavings(new BigDecimal("1800.00"));
        dashboardDTO.setSavingsRate(new BigDecimal("34.6"));
        
        // Initialize other fields to prevent NPEs in the template
        dashboardDTO.setPreviousPeriodIncome(new BigDecimal("4800.00"));
        dashboardDTO.setPreviousPeriodExpenses(new BigDecimal("3200.00"));
        dashboardDTO.setIncomeChangePercentage(new BigDecimal("8.3"));
        dashboardDTO.setExpenseChangePercentage(new BigDecimal("6.2"));
        model.addAttribute("dashboard", dashboardDTO);
        
        return "dashboard/index";
    }
}
