package com.expenseiq.controller;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

/**
 * Controller for handling home page requests.
 * 
 * This controller provides the main entry point to the application
 * and redirects users based on their authentication status.
 */
@Controller
@Slf4j
public class HomeController {

    /**
     * Handles requests to the root URL and always redirects to the dashboard for demo purposes.
     * 
     * @return Redirect to dashboard page
     */
    @GetMapping("/")
    public String home() {
        log.info("Request to home page received - redirecting to dashboard (simplified for demo)");
        return "redirect:/dashboard";
    }
    
    /**
     * Simple test endpoint to verify controller is accessible
     * 
     * @return Plain text message
     */
    @GetMapping("/hello")
    public String hello() {
        log.info("Hello test endpoint accessed");
        return "forward:/hello.html";
    }
}