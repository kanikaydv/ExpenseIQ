package com.expenseiq.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object for financial insights.
 * 
 * This class contains financial insights and predictions for display to users.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InsightDTO {

    private Long id;
    
    private String title;
    
    private String description;
    
    private String type; // spending-trend, saving-tip, prediction, etc.
    
    private String icon;
    
    private String color;
    
    private LocalDateTime generatedDate;
    
    // For spending trends
    private Map<String, BigDecimal> trendData;
    
    // For numeric predictions or comparisons
    private BigDecimal currentValue;
    private BigDecimal previousValue;
    private BigDecimal changePercentage;
    
    // For categorical predictions
    private String category;
    private BigDecimal predictedAmount;
    
    // Priority level for display order
    private Integer priority;
    
    // Action text and URL for actionable insights
    private String actionText;
    private String actionUrl;
}
