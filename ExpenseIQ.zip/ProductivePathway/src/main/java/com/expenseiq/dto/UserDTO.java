package com.expenseiq.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object for User entities.
 * 
 * This class contains the data representation of a user that is passed
 * between the controller and view layers.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {

    private Long id;
    
    @NotBlank(message = "First name is required")
    @Size(max = 50, message = "First name cannot exceed 50 characters")
    private String firstName;
    
    @NotBlank(message = "Last name is required")
    @Size(max = 50, message = "Last name cannot exceed 50 characters")
    private String lastName;
    
    @NotBlank(message = "Email is required")
    @Email(message = "Please provide a valid email address")
    private String email;
    
    // Only used during registration or password change
    private String password;
    
    private String confirmPassword;
    
    // User preferences
    private String currency;
    
    private String locale;
    
    private String theme;
    
    // Account information
    private LocalDateTime registrationDate;
    
    private LocalDateTime lastLoginDate;
    
    private boolean active;
    
    // Email notification preferences
    private boolean emailNotifications;
    
    private boolean monthlyReportEnabled;
    
    private boolean billReminderEnabled;
    
    // Gets the full name by concatenating first and last names
    public String getFullName() {
        return firstName + " " + lastName;
    }
}
