package com.expenseiq.dto;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object for Dashboard display.
 * 
 * This class contains aggregated financial data for display on the dashboard.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardDTO {

    // Summary metrics
    private BigDecimal totalIncome;
    private BigDecimal totalExpenses;
    private BigDecimal netSavings;
    private BigDecimal savingsRate;
    private BigDecimal previousPeriodIncome;
    private BigDecimal previousPeriodExpenses;
    private BigDecimal incomeChangePercentage;
    private BigDecimal expenseChangePercentage;
    
    // Charts data
    private Map<String, BigDecimal> expensesByCategory;
    private Map<String, BigDecimal> incomeByCategory;
    private List<Map<String, Object>> monthlyIncomeData;
    private List<Map<String, Object>> monthlyExpenseData;
    
    // Budget summary
    private List<BudgetDTO> activeBudgets;
    private int nearlydepletedBudgetsCount;
    
    // Recent transactions
    private List<ExpenseDTO> recentExpenses;
    private List<IncomeDTO> recentIncomes;
    
    // Period information
    private String periodLabel;
    private String previousPeriodLabel;
}
