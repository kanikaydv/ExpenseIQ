package com.expenseiq.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object for Budget entities.
 * 
 * This class contains the data representation of a budget that is passed
 * between the controller and view layers.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BudgetDTO {

    private Long id;
    
    @NotBlank(message = "Name is required")
    private String name;
    
    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
    private BigDecimal amount;
    
    @NotNull(message = "Start date is required")
    private LocalDate startDate;
    
    @NotNull(message = "End date is required")
    private LocalDate endDate;
    
    private Long categoryId;
    
    private String categoryName;
    
    // Optional field for budget type (monthly, yearly, etc.)
    private String period;
    
    // Current spending against this budget
    private BigDecimal currentSpending;
    
    // Percentage of budget used
    private Integer percentageUsed;
    
    // Indicates if the budget is nearly depleted (≥90% used)
    private boolean nearlyDepleted;
    
    // Indicates if the budget is expired
    private boolean expired;
}
