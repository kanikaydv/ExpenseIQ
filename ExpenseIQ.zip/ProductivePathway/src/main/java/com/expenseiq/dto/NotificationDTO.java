package com.expenseiq.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object for Notification entities.
 * 
 * This class contains the data representation of a notification that is passed
 * between the controller and view layers.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationDTO {

    private Long id;
    
    private String title;
    
    private String message;
    
    private String type; // alert, info, budget, bill, etc.
    
    private LocalDateTime createdAt;
    
    private boolean read;
    
    // Optional fields for linking to specific resources
    private String actionUrl;
    
    private String actionText;
    
    // Icon and color for UI display
    private String icon;
    
    private String color;
}
