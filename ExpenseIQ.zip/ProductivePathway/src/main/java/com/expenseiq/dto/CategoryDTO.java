package com.expenseiq.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object for Category entities.
 * 
 * This class contains the data representation of a transaction category that is passed
 * between the controller and view layers.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryDTO {

    private Long id;
    
    @NotBlank(message = "Name is required")
    private String name;
    
    private String description;
    
    private String icon;
    
    // Determines if this is an expense or income category
    private String type;
    
    // Indicator for system default categories that shouldn't be deleted
    private boolean isDefault;
    
    // Optional color for UI display
    private String color;
}
