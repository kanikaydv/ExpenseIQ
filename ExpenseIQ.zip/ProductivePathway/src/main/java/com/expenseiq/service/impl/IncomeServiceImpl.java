package com.expenseiq.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.expenseiq.dto.IncomeDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.Category;
import com.expenseiq.model.Income;
import com.expenseiq.model.User;
import com.expenseiq.repository.CategoryRepository;
import com.expenseiq.repository.IncomeRepository;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.IncomeService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the IncomeService interface.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class IncomeServiceImpl implements IncomeService {

    private final IncomeRepository incomeRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;

    @Override
    public List<IncomeDTO> getIncomesByUser(String email) {
        log.info("Getting all incomes for user: {}", email);
        User user = getUserByEmail(email);
        List<Income> incomes = incomeRepository.findByUserId(user.getId());
        return incomes.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public IncomeDTO getIncomeById(Long id, String email) {
        log.info("Getting income with ID: {} for user: {}", id, email);
        User user = getUserByEmail(email);
        Income income = incomeRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Income not found with id: " + id + " for user: " + email));
        return mapToDTO(income);
    }

    @Override
    @Transactional
    public IncomeDTO createIncome(IncomeDTO incomeDTO, String email) {
        log.info("Creating income for user: {}", email);
        User user = getUserByEmail(email);
        
        Income income = new Income();
        updateIncomeFromDTO(income, incomeDTO, user);
        
        Income savedIncome = incomeRepository.save(income);
        log.info("Income created with ID: {}", savedIncome.getId());
        
        return mapToDTO(savedIncome);
    }

    @Override
    @Transactional
    public IncomeDTO updateIncome(IncomeDTO incomeDTO, String email) {
        log.info("Updating income with ID: {} for user: {}", incomeDTO.getId(), email);
        User user = getUserByEmail(email);
        
        Income income = incomeRepository.findByIdAndUserId(incomeDTO.getId(), user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Income not found with id: " + incomeDTO.getId() + " for user: " + email));
        
        updateIncomeFromDTO(income, incomeDTO, user);
        
        Income updatedIncome = incomeRepository.save(income);
        log.info("Income updated with ID: {}", updatedIncome.getId());
        
        return mapToDTO(updatedIncome);
    }

    @Override
    @Transactional
    public boolean deleteIncome(Long id, String email) {
        log.info("Deleting income with ID: {} for user: {}", id, email);
        User user = getUserByEmail(email);
        
        Income income = incomeRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Income not found with id: " + id + " for user: " + email));
        
        incomeRepository.delete(income);
        log.info("Income deleted with ID: {}", id);
        
        return true;
    }

    @Override
    public List<IncomeDTO> getIncomesByDateRange(String email, LocalDate startDate, LocalDate endDate) {
        log.info("Getting incomes for user: {} from {} to {}", email, startDate, endDate);
        User user = getUserByEmail(email);
        List<Income> incomes = incomeRepository.findByUserIdAndDateBetween(user.getId(), startDate, endDate);
        return incomes.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Page<IncomeDTO> getIncomesByDateRangePaginated(String email, LocalDate startDate, LocalDate endDate, 
                                                       int page, int size) {
        log.info("Getting paginated incomes for user: {} from {} to {}", email, startDate, endDate);
        User user = getUserByEmail(email);
        Pageable pageable = PageRequest.of(page, size, Sort.by("date").descending());
        Page<Income> incomesPage = incomeRepository.findByUserIdAndDateBetween(
                user.getId(), startDate, endDate, pageable);
        
        return incomesPage.map(this::mapToDTO);
    }

    @Override
    public List<IncomeDTO> getIncomesByCategory(String email, Long categoryId) {
        log.info("Getting incomes for user: {} in category: {}", email, categoryId);
        User user = getUserByEmail(email);
        List<Income> incomes = incomeRepository.findByUserIdAndCategoryId(user.getId(), categoryId);
        return incomes.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public BigDecimal getTotalIncomesByDateRange(String email, LocalDate startDate, LocalDate endDate) {
        log.info("Getting total incomes for user: {} from {} to {}", email, startDate, endDate);
        User user = getUserByEmail(email);
        return incomeRepository.sumIncomesByDateRange(user.getId(), startDate, endDate);
    }

    @Override
    public Map<String, BigDecimal> getTotalIncomesByCategory(String email, LocalDate startDate, LocalDate endDate) {
        log.info("Getting total incomes by category for user: {} from {} to {}", email, startDate, endDate);
        User user = getUserByEmail(email);
        Map<String, BigDecimal> result = new HashMap<>();
        
        List<Object[]> data = incomeRepository.sumIncomesByCategory(user.getId(), startDate, endDate);
        for (Object[] row : data) {
            String categoryName = (String) row[0];
            BigDecimal amount = (BigDecimal) row[1];
            result.put(categoryName, amount);
        }
        
        return result;
    }

    @Override
    public List<IncomeDTO> getRecentIncomes(String email, int limit) {
        log.info("Getting {} recent incomes for user: {}", limit, email);
        User user = getUserByEmail(email);
        Pageable pageable = PageRequest.of(0, limit);
        List<Income> incomes = incomeRepository.findRecentIncomes(user.getId(), pageable);
        return incomes.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<IncomeDTO> searchIncomes(String email, String searchTerm) {
        log.info("Searching incomes for user: {} with term: {}", email, searchTerm);
        User user = getUserByEmail(email);
        List<Income> incomes = incomeRepository.searchByDescription(user.getId(), searchTerm);
        return incomes.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Maps an Income entity to an IncomeDTO.
     * 
     * @param income The Income entity
     * @return The IncomeDTO
     */
    private IncomeDTO mapToDTO(Income income) {
        IncomeDTO dto = new IncomeDTO();
        dto.setId(income.getId());
        dto.setDescription(income.getDescription());
        dto.setAmount(income.getAmount());
        dto.setDate(income.getDate());
        dto.setSource(income.getSource());
        dto.setNotes(income.getNotes());
        dto.setIsRecurring(income.getIsRecurring());
        dto.setRecurringPeriod(income.getRecurringPeriod());
        
        Category category = income.getCategory();
        dto.setCategoryId(category.getId());
        dto.setCategoryName(category.getName());
        dto.setCategoryIcon(category.getIcon());
        dto.setCategoryColor(category.getColor());
        
        return dto;
    }

    /**
     * Updates an Income entity from an IncomeDTO.
     * 
     * @param income The Income entity to update
     * @param incomeDTO The IncomeDTO with new values
     * @param user The associated User entity
     */
    private void updateIncomeFromDTO(Income income, IncomeDTO incomeDTO, User user) {
        income.setDescription(incomeDTO.getDescription());
        income.setAmount(incomeDTO.getAmount());
        income.setDate(incomeDTO.getDate());
        income.setSource(incomeDTO.getSource());
        income.setNotes(incomeDTO.getNotes());
        income.setIsRecurring(incomeDTO.getIsRecurring());
        income.setRecurringPeriod(incomeDTO.getRecurringPeriod());
        income.setUser(user);
        
        Category category = categoryRepository.findByIdAndUserIdOrSystemDefault(
                incomeDTO.getCategoryId(), user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Category not found with id: " + incomeDTO.getCategoryId()));
        income.setCategory(category);
    }

    /**
     * Gets a User by email.
     * 
     * @param email The email of the user
     * @return The User entity
     * @throws ResourceNotFoundException if the user is not found
     */
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }
}
