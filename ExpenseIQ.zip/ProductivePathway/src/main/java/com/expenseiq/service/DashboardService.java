package com.expenseiq.service;

import java.time.LocalDate;

import com.expenseiq.dto.DashboardDTO;

/**
 * Service interface for dashboard-related operations.
 * 
 * This interface defines methods for retrieving dashboard data.
 */
public interface DashboardService {
    
    /**
     * Gets dashboard data for a user.
     * 
     * @param email The email of the user
     * @param period The time period (month, year, all)
     * @param date The reference date
     * @return The dashboard data
     */
    DashboardDTO getDashboardData(String email, String period, LocalDate date);
    
    /**
     * Gets monthly dashboard data for a user.
     * 
     * @param email The email of the user
     * @param month The month (1-12)
     * @param year The year
     * @return The dashboard data for the month
     */
    DashboardDTO getMonthlyDashboardData(String email, int month, int year);
    
    /**
     * Gets yearly dashboard data for a user.
     * 
     * @param email The email of the user
     * @param year The year
     * @return The dashboard data for the year
     */
    DashboardDTO getYearlyDashboardData(String email, int year);
    
    /**
     * Gets summary metrics for a user.
     * 
     * @param email The email of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return The dashboard data with summary metrics
     */
    DashboardDTO getSummaryMetrics(String email, LocalDate startDate, LocalDate endDate);
}
