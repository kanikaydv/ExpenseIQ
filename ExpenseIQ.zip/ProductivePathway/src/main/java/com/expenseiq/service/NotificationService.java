package com.expenseiq.service;

import java.util.List;

import com.expenseiq.dto.NotificationDTO;

/**
 * Service interface for notification-related operations.
 * 
 * This interface defines methods for managing notifications.
 */
public interface NotificationService {
    
    /**
     * Gets all notifications for a user.
     * 
     * @param email The email of the user
     * @return A list of notification DTOs
     */
    List<NotificationDTO> getNotificationsByUser(String email);
    
    /**
     * Creates a new notification for a user.
     * 
     * @param notification The notification data
     * @param email The email of the user
     * @return The created notification DTO
     */
    NotificationDTO createNotification(NotificationDTO notification, String email);
    
    /**
     * Gets unread notifications for a user.
     * 
     * @param email The email of the user
     * @return A list of unread notification DTOs
     */
    List<NotificationDTO> getUnreadNotifications(String email);
    
    /**
     * Counts unread notifications for a user.
     * 
     * @param email The email of the user
     * @return The count of unread notifications
     */
    long countUnreadNotifications(String email);
    
    /**
     * Gets recent notifications for a user.
     * 
     * @param email The email of the user
     * @param limit The maximum number of notifications to return
     * @return A list of recent notification DTOs
     */
    List<NotificationDTO> getRecentNotifications(String email, int limit);
    
    /**
     * Marks a notification as read.
     * 
     * @param id The ID of the notification
     * @param email The email of the user
     * @return true if the notification was marked as read, false otherwise
     */
    boolean markAsRead(Long id, String email);
    
    /**
     * Marks all notifications as read for a user.
     * 
     * @param email The email of the user
     * @return The number of notifications marked as read
     */
    int markAllAsRead(String email);
    
    /**
     * Creates a budget alert notification.
     * 
     * @param budgetId The ID of the budget
     * @param email The email of the user
     * @param percentage The percentage of the budget used
     * @return The created notification DTO
     */
    NotificationDTO createBudgetAlertNotification(Long budgetId, String email, int percentage);
    
    /**
     * Creates a bill reminder notification.
     * 
     * @param description The bill description
     * @param email The email of the user
     * @param daysUntilDue The number of days until the bill is due
     * @return The created notification DTO
     */
    NotificationDTO createBillReminderNotification(String description, String email, int daysUntilDue);
    
    /**
     * Deletes a notification.
     * 
     * @param id The ID of the notification to delete
     * @param email The email of the user
     * @return true if the notification was deleted, false otherwise
     */
    boolean deleteNotification(Long id, String email);
    
    /**
     * Deletes old notifications.
     * 
     * @param email The email of the user
     * @param daysOld The age threshold in days
     * @return The number of notifications deleted
     */
    int deleteOldNotifications(String email, int daysOld);
}
