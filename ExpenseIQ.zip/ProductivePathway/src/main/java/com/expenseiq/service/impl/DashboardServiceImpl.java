package com.expenseiq.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.expenseiq.dto.BudgetDTO;
import com.expenseiq.dto.DashboardDTO;
import com.expenseiq.dto.ExpenseDTO;
import com.expenseiq.dto.IncomeDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.User;
import com.expenseiq.repository.ExpenseRepository;
import com.expenseiq.repository.IncomeRepository;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.BudgetService;
import com.expenseiq.service.DashboardService;
import com.expenseiq.service.ExpenseService;
import com.expenseiq.service.IncomeService;
import com.expenseiq.util.DateUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the DashboardService interface.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class DashboardServiceImpl implements DashboardService {

    private final UserRepository userRepository;
    private final ExpenseRepository expenseRepository;
    private final IncomeRepository incomeRepository;
    private final ExpenseService expenseService;
    private final IncomeService incomeService;
    private final BudgetService budgetService;
    private final DateUtil dateUtil;

    @Override
    public DashboardDTO getDashboardData(String email, String period, LocalDate date) {
        log.info("Getting dashboard data for user: {} with period: {} and date: {}", email, period, date);
        
        DashboardDTO dashboard = new DashboardDTO();
        
        // Set period information
        LocalDate startDate;
        LocalDate endDate;
        String periodLabel;
        String previousPeriodLabel;
        
        if ("month".equals(period)) {
            startDate = date.withDayOfMonth(1);
            endDate = date.with(TemporalAdjusters.lastDayOfMonth());
            periodLabel = date.format(DateTimeFormatter.ofPattern("MMMM yyyy"));
            
            // Previous period (last month)
            LocalDate previousMonth = date.minusMonths(1);
            previousPeriodLabel = previousMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy"));
        } else if ("year".equals(period)) {
            startDate = date.withDayOfYear(1);
            endDate = date.withDayOfYear(date.lengthOfYear());
            periodLabel = date.format(DateTimeFormatter.ofPattern("yyyy"));
            
            // Previous period (last year)
            LocalDate previousYear = date.minusYears(1);
            previousPeriodLabel = previousYear.format(DateTimeFormatter.ofPattern("yyyy"));
        } else {
            // Default to all time (with reasonable limits)
            startDate = date.minusYears(5); // 5 years back
            endDate = date;
            periodLabel = "All Time";
            previousPeriodLabel = "Previous Period";
        }
        
        dashboard.setPeriodLabel(periodLabel);
        dashboard.setPreviousPeriodLabel(previousPeriodLabel);
        
        // Populate dashboard with data
        populateSummaryMetrics(dashboard, email, period, startDate, endDate);
        populateChartData(dashboard, email, period, startDate, endDate);
        populateBudgetSummary(dashboard, email);
        populateRecentTransactions(dashboard, email);
        
        return dashboard;
    }

    @Override
    public DashboardDTO getMonthlyDashboardData(String email, int month, int year) {
        log.info("Getting monthly dashboard data for user: {} for month: {} and year: {}", email, month, year);
        
        LocalDate date = LocalDate.of(year, month, 1);
        return getDashboardData(email, "month", date);
    }

    @Override
    public DashboardDTO getYearlyDashboardData(String email, int year) {
        log.info("Getting yearly dashboard data for user: {} for year: {}", email, year);
        
        LocalDate date = LocalDate.of(year, 1, 1);
        return getDashboardData(email, "year", date);
    }

    @Override
    public DashboardDTO getSummaryMetrics(String email, LocalDate startDate, LocalDate endDate) {
        log.info("Getting summary metrics for user: {} from {} to {}", email, startDate, endDate);
        
        DashboardDTO dashboard = new DashboardDTO();
        populateSummaryMetrics(dashboard, email, "custom", startDate, endDate);
        return dashboard;
    }

    /**
     * Populates the summary metrics for the dashboard.
     * 
     * @param dashboard The dashboard to populate
     * @param email The email of the user
     * @param period The time period
     * @param startDate The start date
     * @param endDate The end date
     */
    private void populateSummaryMetrics(DashboardDTO dashboard, String email, String period, 
                                      LocalDate startDate, LocalDate endDate) {
        log.debug("Populating summary metrics for period: {} from {} to {}", period, startDate, endDate);
        
        User user = getUserByEmail(email);
        
        // Current period metrics
        BigDecimal totalIncome = incomeRepository.sumIncomesByDateRange(
                user.getId(), startDate, endDate);
        BigDecimal totalExpenses = expenseRepository.sumExpensesByDateRange(
                user.getId(), startDate, endDate);
        BigDecimal netSavings = totalIncome.subtract(totalExpenses);
        
        dashboard.setTotalIncome(totalIncome);
        dashboard.setTotalExpenses(totalExpenses);
        dashboard.setNetSavings(netSavings);
        
        // Calculate savings rate
        if (totalIncome.compareTo(BigDecimal.ZERO) > 0) {
            dashboard.setSavingsRate(netSavings.multiply(new BigDecimal("100"))
                    .divide(totalIncome, 2, RoundingMode.HALF_UP));
        } else {
            dashboard.setSavingsRate(BigDecimal.ZERO);
        }
        
        // Previous period metrics
        LocalDate previousStartDate;
        LocalDate previousEndDate;
        
        if ("month".equals(period)) {
            previousStartDate = startDate.minusMonths(1);
            previousEndDate = endDate.minusMonths(1);
        } else if ("year".equals(period)) {
            previousStartDate = startDate.minusYears(1);
            previousEndDate = endDate.minusYears(1);
        } else {
            // For custom periods, use equal length
            long daysBetween = dateUtil.daysBetween(startDate, endDate);
            previousStartDate = startDate.minusDays(daysBetween);
            previousEndDate = startDate.minusDays(1);
        }
        
        BigDecimal previousIncome = incomeRepository.sumIncomesByDateRange(
                user.getId(), previousStartDate, previousEndDate);
        BigDecimal previousExpenses = expenseRepository.sumExpensesByDateRange(
                user.getId(), previousStartDate, previousEndDate);
        
        dashboard.setPreviousPeriodIncome(previousIncome);
        dashboard.setPreviousPeriodExpenses(previousExpenses);
        
        // Calculate percentage changes
        if (previousIncome.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal incomeChange = totalIncome.subtract(previousIncome)
                    .multiply(new BigDecimal("100"))
                    .divide(previousIncome, 2, RoundingMode.HALF_UP);
            dashboard.setIncomeChangePercentage(incomeChange);
        } else {
            dashboard.setIncomeChangePercentage(BigDecimal.ZERO);
        }
        
        if (previousExpenses.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal expenseChange = totalExpenses.subtract(previousExpenses)
                    .multiply(new BigDecimal("100"))
                    .divide(previousExpenses, 2, RoundingMode.HALF_UP);
            dashboard.setExpenseChangePercentage(expenseChange);
        } else {
            dashboard.setExpenseChangePercentage(BigDecimal.ZERO);
        }
    }

    /**
     * Populates the chart data for the dashboard.
     * 
     * @param dashboard The dashboard to populate
     * @param email The email of the user
     * @param period The time period
     * @param startDate The start date
     * @param endDate The end date
     */
    private void populateChartData(DashboardDTO dashboard, String email, String period, 
                                  LocalDate startDate, LocalDate endDate) {
        log.debug("Populating chart data for period: {} from {} to {}", period, startDate, endDate);
        
        User user = getUserByEmail(email);
        
        // Expenses by category
        Map<String, BigDecimal> expensesByCategory = new HashMap<>();
        List<Object[]> expensesData = expenseRepository.sumExpensesByCategory(
                user.getId(), startDate, endDate);
        
        for (Object[] row : expensesData) {
            String categoryName = (String) row[0];
            BigDecimal amount = (BigDecimal) row[1];
            expensesByCategory.put(categoryName, amount);
        }
        dashboard.setExpensesByCategory(expensesByCategory);
        
        // Income by category
        Map<String, BigDecimal> incomeByCategory = new HashMap<>();
        List<Object[]> incomesData = incomeRepository.sumIncomesByCategory(
                user.getId(), startDate, endDate);
        
        for (Object[] row : incomesData) {
            String categoryName = (String) row[0];
            BigDecimal amount = (BigDecimal) row[1];
            incomeByCategory.put(categoryName, amount);
        }
        dashboard.setIncomeByCategory(incomeByCategory);
        
        // Monthly data for time series charts
        List<Map<String, Object>> monthlyExpenseData = getMonthlyData(user.getId(), startDate, endDate, "expense");
        dashboard.setMonthlyExpenseData(monthlyExpenseData);
        
        List<Map<String, Object>> monthlyIncomeData = getMonthlyData(user.getId(), startDate, endDate, "income");
        dashboard.setMonthlyIncomeData(monthlyIncomeData);
    }

    /**
     * Gets monthly data for time series charts.
     * 
     * @param userId The ID of the user
     * @param startDate The start date
     * @param endDate The end date
     * @param type The type of data ("expense" or "income")
     * @return A list of monthly data maps
     */
    private List<Map<String, Object>> getMonthlyData(Long userId, LocalDate startDate, LocalDate endDate, String type) {
        List<Map<String, Object>> monthlyData = new ArrayList<>();
        LocalDate currentDate = startDate.withDayOfMonth(1);
        
        while (!currentDate.isAfter(endDate)) {
            LocalDate monthEnd = currentDate.with(TemporalAdjusters.lastDayOfMonth());
            BigDecimal amount;
            
            if ("expense".equals(type)) {
                amount = expenseRepository.sumExpensesByDateRange(
                        userId, currentDate, monthEnd);
            } else {
                amount = incomeRepository.sumIncomesByDateRange(
                        userId, currentDate, monthEnd);
            }
            
            Map<String, Object> monthData = new HashMap<>();
            monthData.put("month", currentDate.format(DateTimeFormatter.ofPattern("MMM yyyy")));
            monthData.put("amount", amount);
            
            monthlyData.add(monthData);
            
            currentDate = currentDate.plusMonths(1);
        }
        
        return monthlyData;
    }

    /**
     * Populates the budget summary for the dashboard.
     * 
     * @param dashboard The dashboard to populate
     * @param email The email of the user
     */
    private void populateBudgetSummary(DashboardDTO dashboard, String email) {
        log.debug("Populating budget summary for user: {}", email);
        
        List<BudgetDTO> activeBudgets = budgetService.getActiveBudgets(email);
        dashboard.setActiveBudgets(activeBudgets);
        
        // Count nearly depleted budgets
        int nearlyDepletedCount = (int) activeBudgets.stream()
                .filter(BudgetDTO::isNearlyDepleted)
                .count();
        dashboard.setNearlydepletedBudgetsCount(nearlyDepletedCount);
    }

    /**
     * Populates recent transactions for the dashboard.
     * 
     * @param dashboard The dashboard to populate
     * @param email The email of the user
     */
    private void populateRecentTransactions(DashboardDTO dashboard, String email) {
        log.debug("Populating recent transactions for user: {}", email);
        
        List<ExpenseDTO> recentExpenses = expenseService.getRecentExpenses(email, 5);
        dashboard.setRecentExpenses(recentExpenses);
        
        List<IncomeDTO> recentIncomes = incomeService.getRecentIncomes(email, 5);
        dashboard.setRecentIncomes(recentIncomes);
    }

    /**
     * Gets a User by email.
     * 
     * @param email The email of the user
     * @return The User entity
     * @throws ResourceNotFoundException if the user is not found
     */
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }
}
