package com.expenseiq.service.impl;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.expenseiq.dto.UserDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.User;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the UserService interface.
 * 
 * This service manages user accounts and authentication.
 */
@Service
@Slf4j
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    
    @Autowired(required = false)
    private AuthenticationManager authenticationManager;
    
    @Autowired
    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        log.info("Loading user by username: {}", username);
        return userRepository.findByEmail(username)
                .orElseThrow(() -> {
                    log.error("User not found with email: {}", username);
                    return new UsernameNotFoundException("User not found with email: " + username);
                });
    }

    @Override
    @Transactional
    public UserDTO registerUser(UserDTO userDTO) {
        log.info("Registering new user with email: {}", userDTO.getEmail());
        
        // Check if email already exists
        if (userRepository.existsByEmail(userDTO.getEmail())) {
            log.warn("User registration failed: Email already exists: {}", userDTO.getEmail());
            throw new IllegalArgumentException("Email already exists");
        }
        
        // Create new user entity
        User user = new User();
        user.setFirstName(userDTO.getFirstName());
        user.setLastName(userDTO.getLastName());
        user.setEmail(userDTO.getEmail());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        user.setRole("ROLE_USER");
        user.setCurrency("USD");
        user.setLocale("en_US");
        user.setTheme("light");
        user.setActive(true);
        user.setEmailNotifications(true);
        user.setMonthlyReportEnabled(true);
        user.setBillReminderEnabled(true);
        
        User savedUser = userRepository.save(user);
        log.info("User registered successfully with ID: {}", savedUser.getId());
        
        return mapToDTO(savedUser);
    }

    @Override
    public UserDTO getUserByEmail(String email) {
        log.info("Getting user by email: {}", email);
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
        return mapToDTO(user);
    }

    @Override
    @Transactional
    public UserDTO updateUser(UserDTO userDTO) {
        log.info("Updating user with email: {}", userDTO.getEmail());
        
        User user = userRepository.findByEmail(userDTO.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + userDTO.getEmail()));
        
        // Update user properties
        user.setFirstName(userDTO.getFirstName());
        user.setLastName(userDTO.getLastName());
        user.setCurrency(userDTO.getCurrency());
        user.setLocale(userDTO.getLocale());
        user.setTheme(userDTO.getTheme());
        
        User updatedUser = userRepository.save(user);
        log.info("User updated successfully: {}", updatedUser.getEmail());
        
        return mapToDTO(updatedUser);
    }

    @Override
    @Transactional
    public boolean changePassword(String email, String currentPassword, String newPassword) {
        log.info("Changing password for user: {}", email);
        
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
        
        // Verify current password
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            log.warn("Password change failed: Current password is incorrect for user: {}", email);
            return false;
        }
        
        // Update password
        int updated = userRepository.updatePassword(user.getId(), passwordEncoder.encode(newPassword));
        log.info("Password changed successfully for user: {}", email);
        
        return updated > 0;
    }

    @Override
    @Transactional
    public void updateLastLoginTime(String email) {
        log.info("Updating last login time for user: {}", email);
        userRepository.updateLastLoginDate(email);
    }

    @Override
    public boolean existsByEmail(String email) {
        log.info("Checking if user exists with email: {}", email);
        return userRepository.existsByEmail(email);
    }

    @Override
    @Transactional
    public boolean updateActiveStatus(String email, boolean active) {
        log.info("Updating active status to {} for user: {}", active, email);
        
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
        
        int updated = userRepository.updateActiveStatus(user.getId(), active);
        log.info("Active status updated for user: {}", email);
        
        return updated > 0;
    }

    @Override
    @Transactional
    public UserDTO updateNotificationPreferences(String email, boolean emailNotifications, 
                                              boolean monthlyReportEnabled, boolean billReminderEnabled) {
        log.info("Updating notification preferences for user: {}", email);
        
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
        
        user.setEmailNotifications(emailNotifications);
        user.setMonthlyReportEnabled(monthlyReportEnabled);
        user.setBillReminderEnabled(billReminderEnabled);
        
        User updatedUser = userRepository.save(user);
        log.info("Notification preferences updated for user: {}", email);
        
        return mapToDTO(updatedUser);
    }

    /**
     * Maps a User entity to a UserDTO.
     * 
     * @param user The User entity
     * @return The UserDTO
     */
    private UserDTO mapToDTO(User user) {
        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setFirstName(user.getFirstName());
        dto.setLastName(user.getLastName());
        dto.setEmail(user.getEmail());
        dto.setCurrency(user.getCurrency());
        dto.setLocale(user.getLocale());
        dto.setTheme(user.getTheme());
        dto.setRegistrationDate(user.getRegistrationDate());
        dto.setLastLoginDate(user.getLastLoginDate());
        dto.setActive(user.isActive());
        dto.setEmailNotifications(user.isEmailNotifications());
        dto.setMonthlyReportEnabled(user.isMonthlyReportEnabled());
        dto.setBillReminderEnabled(user.isBillReminderEnabled());
        return dto;
    }
    
    @Override
    public boolean authenticateUser(String username, String password) {
        log.info("Manually authenticating user: {}", username);
        
        try {
            if (authenticationManager != null) {
                // Spring Security way - use the AuthenticationManager if available
                log.info("Using AuthenticationManager for authentication");
                
                // Create authentication token
                UsernamePasswordAuthenticationToken authToken = 
                    new UsernamePasswordAuthenticationToken(username, password);
                
                // Try to authenticate
                Authentication authentication = authenticationManager.authenticate(authToken);
                
                // If authentication was successful, store it in SecurityContext
                if (authentication != null && authentication.isAuthenticated()) {
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    log.info("Authentication successful via AuthenticationManager for user: {}", username);
                    
                    // Update last login time
                    updateLastLoginTime(username);
                    
                    return true;
                }
                
                return false;
            } else {
                // Direct way - manually verify credentials
                log.info("Using direct password verification for authentication");
                
                User user = userRepository.findByEmail(username)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + username));
                
                // Verify the password directly
                if (passwordEncoder.matches(password, user.getPassword())) {
                    // Create authentication token
                    Authentication authentication = new UsernamePasswordAuthenticationToken(
                        user, null, user.getAuthorities());
                    
                    // Set it in the security context
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    log.info("Authentication successful via direct verification for user: {}", username);
                    
                    // Update last login time
                    updateLastLoginTime(username);
                    
                    return true;
                }
                
                log.warn("Authentication failed: Invalid password for user: {}", username);
                return false;
            }
        } catch (AuthenticationException e) {
            log.error("Authentication failed for user: {}", username, e);
            return false;
        } catch (Exception e) {
            log.error("Unexpected error during authentication for user: {}", username, e);
            return false;
        }
    }
}
