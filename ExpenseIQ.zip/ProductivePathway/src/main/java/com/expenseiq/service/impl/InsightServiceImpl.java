package com.expenseiq.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.expenseiq.dto.BudgetDTO;
import com.expenseiq.dto.ExpenseDTO;
import com.expenseiq.dto.InsightDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.Expense;
import com.expenseiq.model.User;
import com.expenseiq.repository.ExpenseRepository;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.BudgetService;
import com.expenseiq.service.ExpenseService;
import com.expenseiq.service.InsightService;
import com.expenseiq.util.DateUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the InsightService interface.
 * 
 * This service generates financial insights based on user transaction data.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class InsightServiceImpl implements InsightService {

    private final ExpenseRepository expenseRepository;
    private final UserRepository userRepository;
    private final ExpenseService expenseService;
    private final BudgetService budgetService;
    private final DateUtil dateUtil;

    @Override
    public List<InsightDTO> getRecentInsights(String email, int limit) {
        log.info("Getting {} recent insights for user: {}", limit, email);
        
        List<InsightDTO> insights = new ArrayList<>();
        
        // Add spending trends
        insights.addAll(getSpendingTrends(email, "month", LocalDate.now()));
        
        // Add savings tips
        insights.addAll(getSavingsTips(email));
        
        // Add budget alerts
        insights.addAll(getNearlyDepletedBudgets(email));
        
        // Sort by priority and limit results
        return insights.stream()
                .sorted(Comparator.comparing(InsightDTO::getPriority))
                .limit(limit)
                .collect(Collectors.toList());
    }

    @Override
    public List<InsightDTO> getSpendingTrends(String email, String period, LocalDate date) {
        log.info("Getting spending trends for user: {} with period: {} and date: {}", email, period, date);
        
        User user = getUserByEmail(email);
        List<InsightDTO> insights = new ArrayList<>();
        
        LocalDate startDate;
        LocalDate endDate;
        LocalDate previousStartDate;
        LocalDate previousEndDate;
        
        // Determine date ranges based on period
        if ("month".equals(period)) {
            // Current month
            startDate = date.withDayOfMonth(1);
            endDate = date.with(TemporalAdjusters.lastDayOfMonth());
            // Previous month
            previousStartDate = date.minusMonths(1).withDayOfMonth(1);
            previousEndDate = date.minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
        } else if ("quarter".equals(period)) {
            // Current quarter
            int quarter = (date.getMonthValue() - 1) / 3 + 1;
            startDate = LocalDate.of(date.getYear(), (quarter - 1) * 3 + 1, 1);
            endDate = LocalDate.of(date.getYear(), quarter * 3, 1)
                    .with(TemporalAdjusters.lastDayOfMonth());
            // Previous quarter
            previousStartDate = startDate.minusMonths(3);
            previousEndDate = endDate.minusMonths(3);
        } else {
            // Current year
            startDate = LocalDate.of(date.getYear(), 1, 1);
            endDate = LocalDate.of(date.getYear(), 12, 31);
            // Previous year
            previousStartDate = LocalDate.of(date.getYear() - 1, 1, 1);
            previousEndDate = LocalDate.of(date.getYear() - 1, 12, 31);
        }
        
        // Get total spending comparison
        BigDecimal currentSpending = expenseRepository.sumExpensesByDateRange(
                user.getId(), startDate, endDate);
        BigDecimal previousSpending = expenseRepository.sumExpensesByDateRange(
                user.getId(), previousStartDate, previousEndDate);
        
        InsightDTO totalSpendingInsight = new InsightDTO();
        totalSpendingInsight.setTitle("Total Spending");
        totalSpendingInsight.setType("spending-trend");
        totalSpendingInsight.setIcon("trending_up");
        totalSpendingInsight.setCurrentValue(currentSpending);
        totalSpendingInsight.setPreviousValue(previousSpending);
        totalSpendingInsight.setGeneratedDate(LocalDateTime.now());
        totalSpendingInsight.setPriority(1);
        
        if (previousSpending.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal changePercentage = currentSpending.subtract(previousSpending)
                    .multiply(new BigDecimal("100"))
                    .divide(previousSpending, 2, RoundingMode.HALF_UP);
            totalSpendingInsight.setChangePercentage(changePercentage);
            
            if (changePercentage.compareTo(BigDecimal.ZERO) > 0) {
                totalSpendingInsight.setDescription("Your spending has increased by " 
                        + changePercentage + "% compared to the previous " + period + ".");
                totalSpendingInsight.setColor("#FF9800"); // Orange for increase
            } else {
                totalSpendingInsight.setDescription("Your spending has decreased by " 
                        + changePercentage.abs() + "% compared to the previous " + period + ".");
                totalSpendingInsight.setColor("#2E7D32"); // Green for decrease
            }
        } else {
            totalSpendingInsight.setDescription("No spending data available for the previous " + period + ".");
            totalSpendingInsight.setColor("#1976D2"); // Blue for neutral
        }
        
        insights.add(totalSpendingInsight);
        
        // Get top spending categories
        Map<String, BigDecimal> expensesByCategory = expenseService.getTotalExpensesByCategory(
                email, startDate, endDate);
        
        if (!expensesByCategory.isEmpty()) {
            // Find top category
            Map.Entry<String, BigDecimal> topCategory = expensesByCategory.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .orElse(null);
            
            if (topCategory != null) {
                InsightDTO topCategoryInsight = new InsightDTO();
                topCategoryInsight.setTitle("Top Spending Category");
                topCategoryInsight.setDescription("Your highest spending this " + period + " was in " 
                        + topCategory.getKey() + " category, totaling " + topCategory.getValue() + ".");
                topCategoryInsight.setType("category-analysis");
                topCategoryInsight.setIcon("pie_chart");
                topCategoryInsight.setColor("#1976D2"); // Blue
                topCategoryInsight.setCategory(topCategory.getKey());
                topCategoryInsight.setCurrentValue(topCategory.getValue());
                topCategoryInsight.setGeneratedDate(LocalDateTime.now());
                topCategoryInsight.setPriority(2);
                
                // Calculate percentage of total spending
                if (currentSpending.compareTo(BigDecimal.ZERO) > 0) {
                    BigDecimal percentage = topCategory.getValue()
                            .multiply(new BigDecimal("100"))
                            .divide(currentSpending, 0, RoundingMode.HALF_UP);
                    topCategoryInsight.setDescription(topCategoryInsight.getDescription() + 
                            " This represents " + percentage + "% of your total spending.");
                }
                
                insights.add(topCategoryInsight);
            }
        }
        
        // Add month-over-month trend
        if ("month".equals(period)) {
            insights.addAll(getMonthlySpendingChanges(email, 3));
        }
        
        return insights;
    }

    @Override
    public List<InsightDTO> getSavingsTips(String email) {
        log.info("Getting savings tips for user: {}", email);
        
        List<InsightDTO> insights = new ArrayList<>();
        
        // Get top spending categories for the last 3 months
        Map<String, Double> topCategories = getTopSpendingCategories(email, 3, 5);
        
        if (!topCategories.isEmpty()) {
            // Generate savings tip for top category
            Map.Entry<String, Double> topCategory = topCategories.entrySet().iterator().next();
            
            InsightDTO savingsTip = new InsightDTO();
            savingsTip.setTitle("Savings Opportunity");
            savingsTip.setDescription("You've spent a significant amount on " + topCategory.getKey() + 
                    ". Consider setting a budget for this category to reduce your expenses.");
            savingsTip.setType("saving-tip");
            savingsTip.setIcon("savings");
            savingsTip.setColor("#2E7D32"); // Green
            savingsTip.setCategory(topCategory.getKey());
            savingsTip.setCurrentValue(new BigDecimal(topCategory.getValue()));
            savingsTip.setGeneratedDate(LocalDateTime.now());
            savingsTip.setPriority(3);
            savingsTip.setActionText("Create Budget");
            savingsTip.setActionUrl("/budget/create");
            
            insights.add(savingsTip);
            
            // Generate generic savings tip
            InsightDTO genericTip = new InsightDTO();
            genericTip.setTitle("Savings Tip");
            genericTip.setDescription("Try the 50/30/20 rule: Allocate 50% of your income to needs, " +
                    "30% to wants, and 20% to savings and debt repayment.");
            genericTip.setType("saving-tip");
            genericTip.setIcon("lightbulb");
            genericTip.setColor("#1976D2"); // Blue
            genericTip.setGeneratedDate(LocalDateTime.now());
            genericTip.setPriority(4);
            
            insights.add(genericTip);
        }
        
        return insights;
    }

    @Override
    public List<InsightDTO> getPredictedExpenses(String email, String period, LocalDate date) {
        log.info("Getting predicted expenses for user: {} with period: {} and date: {}", email, period, date);
        
        List<InsightDTO> insights = new ArrayList<>();
        
        // Get historical expense data for prediction
        LocalDate startDate = date.minusMonths(6);
        LocalDate endDate = date;
        
        User user = getUserByEmail(email);
        List<Expense> expenses = expenseRepository.findByUserIdAndDateBetween(
                user.getId(), startDate, endDate);
        
        // Group expenses by category
        Map<String, List<Expense>> expensesByCategory = expenses.stream()
                .collect(Collectors.groupingBy(e -> e.getCategory().getName()));
        
        // For each category, calculate average monthly spending
        for (Map.Entry<String, List<Expense>> entry : expensesByCategory.entrySet()) {
            String categoryName = entry.getKey();
            List<Expense> categoryExpenses = entry.getValue();
            
            // Calculate total and average
            BigDecimal total = categoryExpenses.stream()
                    .map(Expense::getAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Calculate average (simple prediction model)
            // In a real app, use more sophisticated ML model
            BigDecimal average = total.divide(new BigDecimal(6), 2, RoundingMode.HALF_UP);
            
            // Create prediction insight
            InsightDTO prediction = new InsightDTO();
            prediction.setTitle("Expense Prediction");
            prediction.setDescription("Based on your spending history, we predict you'll spend around " 
                    + average + " on " + categoryName + " next month.");
            prediction.setType("prediction");
            prediction.setIcon("analytics");
            prediction.setColor("#1976D2"); // Blue
            prediction.setCategory(categoryName);
            prediction.setPredictedAmount(average);
            prediction.setGeneratedDate(LocalDateTime.now());
            prediction.setPriority(5);
            
            insights.add(prediction);
        }
        
        return insights;
    }

    @Override
    public Map<String, Double> getTopSpendingCategories(String email, int months, int limit) {
        log.info("Getting top spending categories for user: {} over {} months", email, months);
        
        User user = getUserByEmail(email);
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusMonths(months);
        
        List<Object[]> categoryTotals = expenseRepository.sumExpensesByCategory(
                user.getId(), startDate, endDate);
        
        Map<String, Double> result = new LinkedHashMap<>();
        
        categoryTotals.stream()
                .sorted((a, b) -> ((BigDecimal) b[1]).compareTo((BigDecimal) a[1]))
                .limit(limit)
                .forEach(row -> {
                    String categoryName = (String) row[0];
                    BigDecimal amount = (BigDecimal) row[1];
                    result.put(categoryName, amount.doubleValue());
                });
        
        return result;
    }

    @Override
    public List<InsightDTO> getMonthlySpendingChanges(String email, int months) {
        log.info("Getting monthly spending changes for user: {} over {} months", email, months);
        
        List<InsightDTO> insights = new ArrayList<>();
        User user = getUserByEmail(email);
        
        // Get current month and previous months
        LocalDate currentDate = LocalDate.now();
        
        Map<String, BigDecimal> monthlyTotals = new HashMap<>();
        
        // Calculate totals for each month
        for (int i = 0; i < months; i++) {
            YearMonth yearMonth = YearMonth.from(currentDate.minusMonths(i));
            LocalDate monthStart = yearMonth.atDay(1);
            LocalDate monthEnd = yearMonth.atEndOfMonth();
            
            BigDecimal total = expenseRepository.sumExpensesByDateRange(
                    user.getId(), monthStart, monthEnd);
            
            monthlyTotals.put(yearMonth.toString(), total);
        }
        
        // Create insights for month-over-month changes
        int i = 0;
        for (Map.Entry<String, BigDecimal> entry : monthlyTotals.entrySet()) {
            if (i >= months - 1) break; // Skip the oldest month (no comparison)
            
            YearMonth currentMonth = YearMonth.parse(entry.getKey());
            YearMonth previousMonth = currentMonth.minusMonths(1);
            
            BigDecimal currentTotal = entry.getValue();
            BigDecimal previousTotal = monthlyTotals.get(previousMonth.toString());
            
            if (previousTotal.compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal change = currentTotal.subtract(previousTotal)
                        .multiply(new BigDecimal("100"))
                        .divide(previousTotal, 2, RoundingMode.HALF_UP);
                
                InsightDTO insight = new InsightDTO();
                insight.setTitle(currentMonth.getMonth() + " Spending Change");
                insight.setType("monthly-change");
                insight.setIcon("trending_up");
                insight.setCurrentValue(currentTotal);
                insight.setPreviousValue(previousTotal);
                insight.setChangePercentage(change);
                insight.setGeneratedDate(LocalDateTime.now());
                insight.setPriority(5 + i);
                
                if (change.compareTo(BigDecimal.ZERO) > 0) {
                    insight.setDescription("Your spending in " + currentMonth.getMonth() + 
                            " increased by " + change + "% compared to " + previousMonth.getMonth() + ".");
                    insight.setColor("#FF9800"); // Orange for increase
                } else {
                    insight.setDescription("Your spending in " + currentMonth.getMonth() + 
                            " decreased by " + change.abs() + "% compared to " + previousMonth.getMonth() + ".");
                    insight.setColor("#2E7D32"); // Green for decrease
                }
                
                insights.add(insight);
            }
            
            i++;
        }
        
        return insights;
    }

    @Override
    public List<InsightDTO> getNearlyDepletedBudgets(String email) {
        log.info("Getting nearly depleted budgets for user: {}", email);
        
        List<InsightDTO> insights = new ArrayList<>();
        List<BudgetDTO> activeBudgets = budgetService.getActiveBudgets(email);
        
        for (BudgetDTO budget : activeBudgets) {
            if (budget.isNearlyDepleted()) {
                InsightDTO insight = new InsightDTO();
                insight.setTitle("Budget Alert");
                insight.setDescription("Your " + budget.getName() + " budget is " + 
                        budget.getPercentageUsed() + "% used. Consider reducing spending in this category.");
                insight.setType("budget-alert");
                insight.setIcon("warning");
                insight.setColor("#FF9800"); // Orange for warning
                insight.setCurrentValue(budget.getCurrentSpending());
                insight.setPreviousValue(budget.getAmount());
                insight.setGeneratedDate(LocalDateTime.now());
                insight.setPriority(1); // High priority
                
                insights.add(insight);
            }
        }
        
        return insights;
    }

    @Override
    public List<InsightDTO> getUpcomingBills(String email, int days) {
        log.info("Getting upcoming bills for user: {} within {} days", email, days);
        
        List<InsightDTO> insights = new ArrayList<>();
        User user = getUserByEmail(email);
        
        LocalDate today = LocalDate.now();
        LocalDate endDate = today.plusDays(days);
        
        // Find recurring expenses
        List<ExpenseDTO> recurringExpenses = expenseService.getExpensesByUser(email).stream()
                .filter(e -> Boolean.TRUE.equals(e.getIsRecurring()))
                .collect(Collectors.toList());
        
        for (ExpenseDTO expense : recurringExpenses) {
            // Calculate next occurrence based on recurring period
            LocalDate nextOccurrence = calculateNextOccurrence(expense.getDate(), expense.getRecurringPeriod());
            
            if (nextOccurrence.isAfter(today) && !nextOccurrence.isAfter(endDate)) {
                long daysUntilDue = ChronoUnit.DAYS.between(today, nextOccurrence);
                
                InsightDTO insight = new InsightDTO();
                insight.setTitle("Upcoming Bill");
                insight.setDescription(expense.getDescription() + " payment of " + expense.getAmount() + 
                        " is due in " + daysUntilDue + " days.");
                insight.setType("bill-reminder");
                insight.setIcon("event");
                insight.setColor("#1976D2"); // Blue
                insight.setCurrentValue(expense.getAmount());
                insight.setGeneratedDate(LocalDateTime.now());
                insight.setPriority(2); // High priority
                
                insights.add(insight);
            }
        }
        
        return insights;
    }

    /**
     * Calculates the next occurrence of a recurring transaction.
     * 
     * @param lastDate The last occurrence date
     * @param recurringPeriod The recurring period (daily, weekly, monthly, yearly)
     * @return The next occurrence date
     */
    private LocalDate calculateNextOccurrence(LocalDate lastDate, String recurringPeriod) {
        if (recurringPeriod == null) {
            return lastDate;
        }
        
        LocalDate today = LocalDate.now();
        LocalDate nextDate = lastDate;
        
        while (nextDate.isBefore(today) || nextDate.isEqual(today)) {
            switch (recurringPeriod.toLowerCase()) {
                case "daily":
                    nextDate = nextDate.plusDays(1);
                    break;
                case "weekly":
                    nextDate = nextDate.plusWeeks(1);
                    break;
                case "monthly":
                    nextDate = nextDate.plusMonths(1);
                    break;
                case "yearly":
                    nextDate = nextDate.plusYears(1);
                    break;
                default:
                    return nextDate;
            }
        }
        
        return nextDate;
    }

    /**
     * Gets a User by email.
     * 
     * @param email The email of the user
     * @return The User entity
     * @throws ResourceNotFoundException if the user is not found
     */
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }
}
