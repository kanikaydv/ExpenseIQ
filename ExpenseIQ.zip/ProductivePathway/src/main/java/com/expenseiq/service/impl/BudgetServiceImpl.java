package com.expenseiq.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.expenseiq.dto.BudgetDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.Budget;
import com.expenseiq.model.Category;
import com.expenseiq.model.User;
import com.expenseiq.repository.BudgetRepository;
import com.expenseiq.repository.CategoryRepository;
import com.expenseiq.repository.ExpenseRepository;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.BudgetService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the BudgetService interface.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class BudgetServiceImpl implements BudgetService {

    private final BudgetRepository budgetRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final ExpenseRepository expenseRepository;

    @Override
    public List<BudgetDTO> getBudgetsByUser(String email) {
        log.info("Getting all budgets for user: {}", email);
        User user = getUserByEmail(email);
        List<Budget> budgets = budgetRepository.findByUserId(user.getId());
        return budgets.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public BudgetDTO getBudgetById(Long id, String email) {
        log.info("Getting budget with ID: {} for user: {}", id, email);
        User user = getUserByEmail(email);
        Budget budget = budgetRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Budget not found with id: " + id + " for user: " + email));
        return mapToDTO(budget);
    }

    @Override
    @Transactional
    public BudgetDTO createBudget(BudgetDTO budgetDTO, String email) {
        log.info("Creating budget for user: {}", email);
        User user = getUserByEmail(email);
        Budget budget = new Budget();
        
        updateBudgetFromDTO(budget, budgetDTO, user);
        
        budget.setCreatedAt(LocalDate.now());
        Budget savedBudget = budgetRepository.save(budget);
        log.info("Budget created with ID: {}", savedBudget.getId());
        
        return mapToDTO(savedBudget);
    }

    @Override
    @Transactional
    public BudgetDTO updateBudget(BudgetDTO budgetDTO, String email) {
        log.info("Updating budget with ID: {} for user: {}", budgetDTO.getId(), email);
        User user = getUserByEmail(email);
        
        Budget budget = budgetRepository.findByIdAndUserId(budgetDTO.getId(), user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Budget not found with id: " + budgetDTO.getId() + " for user: " + email));
        
        updateBudgetFromDTO(budget, budgetDTO, user);
        
        Budget updatedBudget = budgetRepository.save(budget);
        log.info("Budget updated with ID: {}", updatedBudget.getId());
        
        return mapToDTO(updatedBudget);
    }

    @Override
    @Transactional
    public boolean deleteBudget(Long id, String email) {
        log.info("Deleting budget with ID: {} for user: {}", id, email);
        User user = getUserByEmail(email);
        
        Budget budget = budgetRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Budget not found with id: " + id + " for user: " + email));
        
        budgetRepository.delete(budget);
        log.info("Budget deleted with ID: {}", id);
        
        return true;
    }

    @Override
    public List<BudgetDTO> getActiveBudgets(String email) {
        log.info("Getting active budgets for user: {}", email);
        User user = getUserByEmail(email);
        List<Budget> activeBudgets = budgetRepository.findActiveBudgets(user.getId(), LocalDate.now());
        
        return activeBudgets.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<BudgetDTO> getActiveBudgetsByCategory(String email, Long categoryId) {
        log.info("Getting active budgets for category: {} for user: {}", categoryId, email);
        User user = getUserByEmail(email);
        List<Budget> activeBudgets = budgetRepository.findActiveBudgetsByCategory(
                user.getId(), categoryId, LocalDate.now());
        
        return activeBudgets.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<BudgetDTO> getBudgetsExpiringSoon(String email, int days) {
        log.info("Getting budgets expiring within {} days for user: {}", days, email);
        User user = getUserByEmail(email);
        LocalDate now = LocalDate.now();
        LocalDate endDate = now.plusDays(days);
        
        List<Budget> expiringBudgets = budgetRepository.findBudgetsExpiringBetween(
                user.getId(), now, endDate);
        
        return expiringBudgets.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public boolean isBudgetNearlyDepleted(Long id, String email) {
        log.info("Checking if budget with ID: {} is nearly depleted for user: {}", id, email);
        int percentage = getBudgetUsagePercentage(id, email);
        return percentage >= 90;
    }

    @Override
    public int getBudgetUsagePercentage(Long id, String email) {
        log.info("Getting usage percentage for budget with ID: {} for user: {}", id, email);
        User user = getUserByEmail(email);
        
        Budget budget = budgetRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Budget not found with id: " + id + " for user: " + email));
        
        BigDecimal currentSpending;
        if (budget.getCategory() != null) {
            // Category-specific budget
            currentSpending = expenseRepository.sumExpensesByCategoryAndDateRange(
                    user.getId(), budget.getCategory().getId(), budget.getStartDate(), budget.getEndDate());
        } else {
            // Total budget
            currentSpending = expenseRepository.sumExpensesByDateRange(
                    user.getId(), budget.getStartDate(), budget.getEndDate());
        }
        
        if (budget.getAmount().compareTo(BigDecimal.ZERO) == 0) {
            return 0;
        }
        
        // Calculate percentage
        BigDecimal percentage = currentSpending.multiply(new BigDecimal("100"))
                .divide(budget.getAmount(), 0, RoundingMode.HALF_UP);
        
        return percentage.intValue();
    }

    /**
     * Maps a Budget entity to a BudgetDTO.
     * 
     * @param budget The Budget entity
     * @return The BudgetDTO
     */
    private BudgetDTO mapToDTO(Budget budget) {
        BudgetDTO dto = new BudgetDTO();
        dto.setId(budget.getId());
        dto.setName(budget.getName());
        dto.setAmount(budget.getAmount());
        dto.setStartDate(budget.getStartDate());
        dto.setEndDate(budget.getEndDate());
        dto.setPeriod(budget.getPeriod());
        
        if (budget.getCategory() != null) {
            dto.setCategoryId(budget.getCategory().getId());
            dto.setCategoryName(budget.getCategory().getName());
        }
        
        // Calculate current spending and percentage
        BigDecimal currentSpending;
        if (budget.getCategory() != null) {
            // Category-specific budget
            currentSpending = expenseRepository.sumExpensesByCategoryAndDateRange(
                    budget.getUser().getId(), budget.getCategory().getId(), budget.getStartDate(), budget.getEndDate());
        } else {
            // Total budget
            currentSpending = expenseRepository.sumExpensesByDateRange(
                    budget.getUser().getId(), budget.getStartDate(), budget.getEndDate());
        }
        
        dto.setCurrentSpending(currentSpending);
        
        // Calculate percentage used
        if (budget.getAmount().compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal percentage = currentSpending.multiply(new BigDecimal("100"))
                    .divide(budget.getAmount(), 0, RoundingMode.HALF_UP);
            dto.setPercentageUsed(percentage.intValue());
            dto.setNearlyDepleted(percentage.intValue() >= 90);
        } else {
            dto.setPercentageUsed(0);
            dto.setNearlyDepleted(false);
        }
        
        // Check if expired
        dto.setExpired(budget.isExpired());
        
        return dto;
    }

    /**
     * Updates a Budget entity from a BudgetDTO.
     * 
     * @param budget The Budget entity to update
     * @param budgetDTO The BudgetDTO with new values
     * @param user The associated User entity
     */
    private void updateBudgetFromDTO(Budget budget, BudgetDTO budgetDTO, User user) {
        budget.setName(budgetDTO.getName());
        budget.setAmount(budgetDTO.getAmount());
        budget.setStartDate(budgetDTO.getStartDate());
        budget.setEndDate(budgetDTO.getEndDate());
        budget.setPeriod(budgetDTO.getPeriod());
        budget.setUser(user);
        
        if (budgetDTO.getCategoryId() != null) {
            Category category = categoryRepository.findByIdAndUserIdOrSystemDefault(
                    budgetDTO.getCategoryId(), user.getId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Category not found with id: " + budgetDTO.getCategoryId()));
            budget.setCategory(category);
        } else {
            budget.setCategory(null);
        }
    }

    /**
     * Gets a User by email.
     * 
     * @param email The email of the user
     * @return The User entity
     * @throws ResourceNotFoundException if the user is not found
     */
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }
}
