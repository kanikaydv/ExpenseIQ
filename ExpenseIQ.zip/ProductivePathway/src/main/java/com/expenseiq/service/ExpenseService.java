package com.expenseiq.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.expenseiq.dto.ExpenseDTO;

/**
 * Service interface for expense-related operations.
 * 
 * This interface defines methods for managing expenses.
 */
public interface ExpenseService {
    
    /**
     * Gets all expenses for a user.
     * 
     * @param email The email of the user
     * @return A list of expense DTOs
     */
    List<ExpenseDTO> getExpensesByUser(String email);
    
    /**
     * Gets a specific expense by ID for a user.
     * 
     * @param id The ID of the expense
     * @param email The email of the user
     * @return The expense DTO
     */
    ExpenseDTO getExpenseById(Long id, String email);
    
    /**
     * Creates a new expense for a user.
     * 
     * @param expenseDTO The expense data
     * @param email The email of the user
     * @return The created expense DTO
     */
    ExpenseDTO createExpense(ExpenseDTO expenseDTO, String email);
    
    /**
     * Updates an existing expense for a user.
     * 
     * @param expenseDTO The updated expense data
     * @param email The email of the user
     * @return The updated expense DTO
     */
    ExpenseDTO updateExpense(ExpenseDTO expenseDTO, String email);
    
    /**
     * Deletes an expense.
     * 
     * @param id The ID of the expense to delete
     * @param email The email of the user
     * @return true if the expense was deleted, false otherwise
     */
    boolean deleteExpense(Long id, String email);
    
    /**
     * Gets expenses for a date range.
     * 
     * @param email The email of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return A list of expense DTOs in the date range
     */
    List<ExpenseDTO> getExpensesByDateRange(String email, LocalDate startDate, LocalDate endDate);
    
    /**
     * Gets expenses for a date range, paginated.
     * 
     * @param email The email of the user
     * @param startDate The start date
     * @param endDate The end date
     * @param page The page number (0-based)
     * @param size The page size
     * @return A page of expense DTOs
     */
    Page<ExpenseDTO> getExpensesByDateRangePaginated(String email, LocalDate startDate, LocalDate endDate, int page, int size);
    
    /**
     * Gets expenses for a specific category.
     * 
     * @param email The email of the user
     * @param categoryId The ID of the category
     * @return A list of expense DTOs for the category
     */
    List<ExpenseDTO> getExpensesByCategory(String email, Long categoryId);
    
    /**
     * Gets the total expenses for a date range.
     * 
     * @param email The email of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return The total expenses
     */
    BigDecimal getTotalExpensesByDateRange(String email, LocalDate startDate, LocalDate endDate);
    
    /**
     * Gets the total expenses by category for a date range.
     * 
     * @param email The email of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return A map of category names to total expenses
     */
    Map<String, BigDecimal> getTotalExpensesByCategory(String email, LocalDate startDate, LocalDate endDate);
    
    /**
     * Gets recent expenses for a user.
     * 
     * @param email The email of the user
     * @param limit The maximum number of expenses to return
     * @return A list of recent expense DTOs
     */
    List<ExpenseDTO> getRecentExpenses(String email, int limit);
    
    /**
     * Searches expenses by description.
     * 
     * @param email The email of the user
     * @param searchTerm The search term
     * @return A list of matching expense DTOs
     */
    List<ExpenseDTO> searchExpenses(String email, String searchTerm);
}
