package com.expenseiq.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.expenseiq.dto.InsightDTO;

/**
 * Service interface for financial insights.
 * 
 * This interface defines methods for generating and retrieving financial insights.
 */
public interface InsightService {
    
    /**
     * Gets recent insights for a user.
     * 
     * @param email The email of the user
     * @param limit The maximum number of insights to return
     * @return A list of recent insight DTOs
     */
    List<InsightDTO> getRecentInsights(String email, int limit);
    
    /**
     * Gets spending trends for a user over a time period.
     * 
     * @param email The email of the user
     * @param period The time period (month, quarter, year)
     * @param date The reference date
     * @return A list of insights representing spending trends
     */
    List<InsightDTO> getSpendingTrends(String email, String period, LocalDate date);
    
    /**
     * Gets savings tips for a user based on spending patterns.
     * 
     * @param email The email of the user
     * @return A list of savings tip insights
     */
    List<InsightDTO> getSavingsTips(String email);
    
    /**
     * Gets predicted expenses for future periods.
     * 
     * @param email The email of the user
     * @param period The time period for predictions (month, quarter, year)
     * @param date The reference date
     * @return A list of predicted expense insights
     */
    List<InsightDTO> getPredictedExpenses(String email, String period, LocalDate date);
    
    /**
     * Gets the top spending categories for a user.
     * 
     * @param email The email of the user
     * @param months The number of months to analyze
     * @param limit The maximum number of categories to return
     * @return A map of category names to amounts
     */
    Map<String, Double> getTopSpendingCategories(String email, int months, int limit);
    
    /**
     * Gets month-over-month spending changes.
     * 
     * @param email The email of the user
     * @param months The number of months to analyze
     * @return A list of insights representing monthly changes
     */
    List<InsightDTO> getMonthlySpendingChanges(String email, int months);
    
    /**
     * Generates insights for budgets that are nearly depleted.
     * 
     * @param email The email of the user
     * @return A list of insights for budgets that are ≥90% used
     */
    List<InsightDTO> getNearlyDepletedBudgets(String email);
    
    /**
     * Generates insights for upcoming bill payments.
     * 
     * @param email The email of the user
     * @param days The number of days to look ahead
     * @return A list of insights for upcoming bills
     */
    List<InsightDTO> getUpcomingBills(String email, int days);
}
