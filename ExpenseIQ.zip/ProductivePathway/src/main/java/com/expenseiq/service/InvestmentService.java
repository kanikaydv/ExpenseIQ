package com.expenseiq.service;

import java.util.List;

import com.expenseiq.dto.InsightDTO;

/**
 * Service interface for investment recommendations.
 * 
 * This interface defines methods for generating investment suggestions.
 */
public interface InvestmentService {
    
    /**
     * Gets investment suggestions for a user based on their financial data.
     * 
     * @param email The email of the user
     * @return A list of investment suggestion insights
     */
    List<InsightDTO> getInvestmentSuggestions(String email);
    
    /**
     * Gets personalized investment recommendations based on user profile.
     * 
     * @param email The email of the user
     * @return A list of personalized investment insights
     */
    List<InsightDTO> getPersonalizedRecommendations(String email);
    
    /**
     * Gets savings rate analysis for a user.
     * 
     * @param email The email of the user
     * @return An insight with savings rate analysis
     */
    InsightDTO getSavingsRateAnalysis(String email);
    
    /**
     * Gets investment diversification recommendations.
     * 
     * @param email The email of the user
     * @return A list of diversification insights
     */
    List<InsightDTO> getDiversificationRecommendations(String email);
    
    /**
     * Gets retirement planning insights.
     * 
     * @param email The email of the user
     * @return A list of retirement planning insights
     */
    List<InsightDTO> getRetirementPlanningInsights(String email);
}
