package com.expenseiq.service;

import java.util.List;

import com.expenseiq.dto.CategoryDTO;

/**
 * Service interface for category-related operations.
 * 
 * This interface defines methods for managing transaction categories.
 */
public interface CategoryService {
    
    /**
     * Gets all categories available to a user.
     * 
     * @return A list of category DTOs
     */
    List<CategoryDTO> getAllCategories();
    
    /**
     * Gets all expense categories.
     * 
     * @return A list of expense category DTOs
     */
    List<CategoryDTO> getExpenseCategories();
    
    /**
     * Gets all income categories.
     * 
     * @return A list of income category DTOs
     */
    List<CategoryDTO> getIncomeCategories();
    
    /**
     * Gets a specific category by ID.
     * 
     * @param id The ID of the category
     * @return The category DTO
     */
    CategoryDTO getCategoryById(Long id);
    
    /**
     * Creates a new category.
     * 
     * @param categoryDTO The category data
     * @param email The email of the user
     * @return The created category DTO
     */
    CategoryDTO createCategory(CategoryDTO categoryDTO, String email);
    
    /**
     * Updates an existing category.
     * 
     * @param categoryDTO The updated category data
     * @param email The email of the user
     * @return The updated category DTO
     */
    CategoryDTO updateCategory(CategoryDTO categoryDTO, String email);
    
    /**
     * Deletes a category.
     * 
     * @param id The ID of the category to delete
     * @param email The email of the user
     * @return true if the category was deleted, false otherwise
     */
    boolean deleteCategory(Long id, String email);
    
    /**
     * Gets custom categories created by a user.
     * 
     * @param email The email of the user
     * @return A list of custom category DTOs
     */
    List<CategoryDTO> getCustomCategories(String email);
    
    /**
     * Gets system default categories.
     * 
     * @return A list of system category DTOs
     */
    List<CategoryDTO> getSystemCategories();
    
    /**
     * Checks if a category name already exists for a user.
     * 
     * @param name The category name to check
     * @param email The email of the user
     * @return true if the category name exists, false otherwise
     */
    boolean existsByName(String name, String email);
}
