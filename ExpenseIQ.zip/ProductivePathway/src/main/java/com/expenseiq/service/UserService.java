package com.expenseiq.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.expenseiq.dto.UserDTO;

/**
 * Service interface for user-related operations.
 * 
 * This interface extends UserDetailsService for Spring Security integration
 * and defines methods for managing users.
 */
public interface UserService extends UserDetailsService {
    
    /**
     * Registers a new user.
     * 
     * @param userDTO The user registration data
     * @return The registered user DTO
     */
    UserDTO registerUser(UserDTO userDTO);
    
    /**
     * Gets a user by email.
     * 
     * @param email The email of the user
     * @return The user DTO
     */
    UserDTO getUserByEmail(String email);
    
    /**
     * Updates user details.
     * 
     * @param userDTO The updated user data
     * @return The updated user DTO
     */
    UserDTO updateUser(UserDTO userDTO);
    
    /**
     * Changes a user's password.
     * 
     * @param email The email of the user
     * @param currentPassword The current password
     * @param newPassword The new password
     * @return true if the password was changed, false otherwise
     */
    boolean changePassword(String email, String currentPassword, String newPassword);
    
    /**
     * Updates a user's last login timestamp.
     * 
     * @param email The email of the user
     */
    void updateLastLoginTime(String email);
    
    /**
     * Checks if a user with the given email exists.
     * 
     * @param email The email to check
     * @return true if a user with the email exists, false otherwise
     */
    boolean existsByEmail(String email);
    
    /**
     * Updates a user's active status.
     * 
     * @param email The email of the user
     * @param active The new active status
     * @return true if the status was updated, false otherwise
     */
    boolean updateActiveStatus(String email, boolean active);
    
    /**
     * Updates notification preferences.
     * 
     * @param email The email of the user
     * @param emailNotifications Whether to enable email notifications
     * @param monthlyReportEnabled Whether to enable monthly reports
     * @param billReminderEnabled Whether to enable bill reminders
     * @return The updated user DTO
     */
    UserDTO updateNotificationPreferences(String email, boolean emailNotifications, 
                                         boolean monthlyReportEnabled, boolean billReminderEnabled);
                                         
    /**
     * Authenticates a user with username and password.
     * 
     * @param username The user's email address
     * @param password The user's password
     * @return True if authentication was successful
     * @throws org.springframework.security.core.AuthenticationException if authentication fails
     */
    boolean authenticateUser(String username, String password);
}
