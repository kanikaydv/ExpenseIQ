package com.expenseiq.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.expenseiq.dto.NotificationDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.Notification;
import com.expenseiq.model.User;
import com.expenseiq.repository.BudgetRepository;
import com.expenseiq.repository.NotificationRepository;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.NotificationService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the NotificationService interface.
 * 
 * This service manages notifications for users.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;
    private final BudgetRepository budgetRepository;

    @Override
    public List<NotificationDTO> getNotificationsByUser(String email) {
        log.info("Getting all notifications for user: {}", email);
        User user = getUserByEmail(email);
        List<Notification> notifications = notificationRepository.findByUserIdOrderByCreatedAtDesc(user.getId());
        return notifications.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public NotificationDTO createNotification(NotificationDTO notificationDTO, String email) {
        log.info("Creating notification for user: {}", email);
        User user = getUserByEmail(email);
        
        Notification notification = new Notification();
        updateNotificationFromDTO(notification, notificationDTO);
        notification.setUser(user);
        notification.setCreatedAt(LocalDateTime.now());
        notification.setRead(false);
        
        Notification savedNotification = notificationRepository.save(notification);
        log.info("Notification created with ID: {}", savedNotification.getId());
        
        return mapToDTO(savedNotification);
    }

    @Override
    public List<NotificationDTO> getUnreadNotifications(String email) {
        log.info("Getting unread notifications for user: {}", email);
        User user = getUserByEmail(email);
        List<Notification> notifications = notificationRepository.findUnreadByUserId(user.getId());
        return notifications.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public long countUnreadNotifications(String email) {
        log.info("Counting unread notifications for user: {}", email);
        User user = getUserByEmail(email);
        return notificationRepository.countUnreadByUserId(user.getId());
    }

    @Override
    public List<NotificationDTO> getRecentNotifications(String email, int limit) {
        log.info("Getting {} recent notifications for user: {}", limit, email);
        User user = getUserByEmail(email);
        List<Notification> notifications = notificationRepository.findRecentByUserId(
                user.getId(), PageRequest.of(0, limit, Sort.by("createdAt").descending()));
        return notifications.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public boolean markAsRead(Long id, String email) {
        log.info("Marking notification with ID: {} as read for user: {}", id, email);
        User user = getUserByEmail(email);
        
        // Verify notification belongs to user
        Notification notification = notificationRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Notification not found with id: " + id + " for user: " + email));
        
        int updated = notificationRepository.markAsRead(id, user.getId());
        log.info("Notification {} marked as read: {}", id, updated > 0);
        
        return updated > 0;
    }

    @Override
    @Transactional
    public int markAllAsRead(String email) {
        log.info("Marking all notifications as read for user: {}", email);
        User user = getUserByEmail(email);
        int updated = notificationRepository.markAllAsRead(user.getId());
        log.info("{} notifications marked as read for user: {}", updated, email);
        return updated;
    }

    @Override
    @Transactional
    public NotificationDTO createBudgetAlertNotification(Long budgetId, String email, int percentage) {
        log.info("Creating budget alert notification for budget: {} and user: {}", budgetId, email);
        User user = getUserByEmail(email);
        
        // Get budget name
        String budgetName = budgetRepository.findById(budgetId)
                .map(budget -> budget.getName())
                .orElse("Unknown Budget");
        
        NotificationDTO notificationDTO = new NotificationDTO();
        notificationDTO.setTitle("Budget Alert");
        notificationDTO.setMessage("Your " + budgetName + " budget has reached " + percentage + "% of its limit.");
        notificationDTO.setType("budget");
        notificationDTO.setIcon("warning");
        notificationDTO.setColor("#FF9800"); // Orange for warning
        notificationDTO.setActionUrl("/budget/" + budgetId);
        notificationDTO.setActionText("View Budget");
        
        return createNotification(notificationDTO, email);
    }

    @Override
    @Transactional
    public NotificationDTO createBillReminderNotification(String description, String email, int daysUntilDue) {
        log.info("Creating bill reminder notification for user: {}", email);
        
        NotificationDTO notificationDTO = new NotificationDTO();
        notificationDTO.setTitle("Upcoming Bill");
        notificationDTO.setMessage(description + " is due in " + daysUntilDue + " days.");
        notificationDTO.setType("bill");
        notificationDTO.setIcon("event");
        notificationDTO.setColor("#1976D2"); // Blue
        
        return createNotification(notificationDTO, email);
    }

    @Override
    @Transactional
    public boolean deleteNotification(Long id, String email) {
        log.info("Deleting notification with ID: {} for user: {}", id, email);
        User user = getUserByEmail(email);
        
        // Verify notification belongs to user
        Notification notification = notificationRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Notification not found with id: " + id + " for user: " + email));
        
        notificationRepository.delete(notification);
        log.info("Notification deleted with ID: {}", id);
        
        return true;
    }

    @Override
    @Transactional
    public int deleteOldNotifications(String email, int daysOld) {
        log.info("Deleting notifications older than {} days for user: {}", daysOld, email);
        User user = getUserByEmail(email);
        
        LocalDateTime threshold = LocalDateTime.now().minusDays(daysOld);
        int deleted = notificationRepository.deleteOldNotifications(user.getId(), threshold);
        log.info("{} old notifications deleted for user: {}", deleted, email);
        
        return deleted;
    }

    /**
     * Maps a Notification entity to a NotificationDTO.
     * 
     * @param notification The Notification entity
     * @return The NotificationDTO
     */
    private NotificationDTO mapToDTO(Notification notification) {
        NotificationDTO dto = new NotificationDTO();
        dto.setId(notification.getId());
        dto.setTitle(notification.getTitle());
        dto.setMessage(notification.getMessage());
        dto.setType(notification.getType());
        dto.setCreatedAt(notification.getCreatedAt());
        dto.setRead(notification.isRead());
        dto.setActionUrl(notification.getActionUrl());
        dto.setActionText(notification.getActionText());
        dto.setIcon(notification.getIcon());
        dto.setColor(notification.getColor());
        return dto;
    }

    /**
     * Updates a Notification entity from a NotificationDTO.
     * 
     * @param notification The Notification entity to update
     * @param notificationDTO The NotificationDTO with new values
     */
    private void updateNotificationFromDTO(Notification notification, NotificationDTO notificationDTO) {
        notification.setTitle(notificationDTO.getTitle());
        notification.setMessage(notificationDTO.getMessage());
        notification.setType(notificationDTO.getType());
        notification.setActionUrl(notificationDTO.getActionUrl());
        notification.setActionText(notificationDTO.getActionText());
        notification.setIcon(notificationDTO.getIcon());
        notification.setColor(notificationDTO.getColor());
    }

    /**
     * Gets a User by email.
     * 
     * @param email The email of the user
     * @return The User entity
     * @throws ResourceNotFoundException if the user is not found
     */
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }
}
