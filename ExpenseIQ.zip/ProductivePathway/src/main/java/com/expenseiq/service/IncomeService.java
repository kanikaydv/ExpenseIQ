package com.expenseiq.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.expenseiq.dto.IncomeDTO;

/**
 * Service interface for income-related operations.
 * 
 * This interface defines methods for managing incomes.
 */
public interface IncomeService {
    
    /**
     * Gets all incomes for a user.
     * 
     * @param email The email of the user
     * @return A list of income DTOs
     */
    List<IncomeDTO> getIncomesByUser(String email);
    
    /**
     * Gets a specific income by ID for a user.
     * 
     * @param id The ID of the income
     * @param email The email of the user
     * @return The income DTO
     */
    IncomeDTO getIncomeById(Long id, String email);
    
    /**
     * Creates a new income for a user.
     * 
     * @param incomeDTO The income data
     * @param email The email of the user
     * @return The created income DTO
     */
    IncomeDTO createIncome(IncomeDTO incomeDTO, String email);
    
    /**
     * Updates an existing income for a user.
     * 
     * @param incomeDTO The updated income data
     * @param email The email of the user
     * @return The updated income DTO
     */
    IncomeDTO updateIncome(IncomeDTO incomeDTO, String email);
    
    /**
     * Deletes an income.
     * 
     * @param id The ID of the income to delete
     * @param email The email of the user
     * @return true if the income was deleted, false otherwise
     */
    boolean deleteIncome(Long id, String email);
    
    /**
     * Gets incomes for a date range.
     * 
     * @param email The email of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return A list of income DTOs in the date range
     */
    List<IncomeDTO> getIncomesByDateRange(String email, LocalDate startDate, LocalDate endDate);
    
    /**
     * Gets incomes for a date range, paginated.
     * 
     * @param email The email of the user
     * @param startDate The start date
     * @param endDate The end date
     * @param page The page number (0-based)
     * @param size The page size
     * @return A page of income DTOs
     */
    Page<IncomeDTO> getIncomesByDateRangePaginated(String email, LocalDate startDate, LocalDate endDate, int page, int size);
    
    /**
     * Gets incomes for a specific category.
     * 
     * @param email The email of the user
     * @param categoryId The ID of the category
     * @return A list of income DTOs for the category
     */
    List<IncomeDTO> getIncomesByCategory(String email, Long categoryId);
    
    /**
     * Gets the total incomes for a date range.
     * 
     * @param email The email of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return The total incomes
     */
    BigDecimal getTotalIncomesByDateRange(String email, LocalDate startDate, LocalDate endDate);
    
    /**
     * Gets the total incomes by category for a date range.
     * 
     * @param email The email of the user
     * @param startDate The start date
     * @param endDate The end date
     * @return A map of category names to total incomes
     */
    Map<String, BigDecimal> getTotalIncomesByCategory(String email, LocalDate startDate, LocalDate endDate);
    
    /**
     * Gets recent incomes for a user.
     * 
     * @param email The email of the user
     * @param limit The maximum number of incomes to return
     * @return A list of recent income DTOs
     */
    List<IncomeDTO> getRecentIncomes(String email, int limit);
    
    /**
     * Searches incomes by description.
     * 
     * @param email The email of the user
     * @param searchTerm The search term
     * @return A list of matching income DTOs
     */
    List<IncomeDTO> searchIncomes(String email, String searchTerm);
}
