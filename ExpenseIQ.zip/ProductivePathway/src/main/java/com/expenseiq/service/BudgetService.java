package com.expenseiq.service;

import java.util.List;

import com.expenseiq.dto.BudgetDTO;

/**
 * Service interface for budget-related operations.
 * 
 * This interface defines methods for managing budgets.
 */
public interface BudgetService {
    
    /**
     * Gets all budgets for a user.
     * 
     * @param email The email of the user
     * @return A list of budget DTOs
     */
    List<BudgetDTO> getBudgetsByUser(String email);
    
    /**
     * Gets a specific budget by ID for a user.
     * 
     * @param id The ID of the budget
     * @param email The email of the user
     * @return The budget DTO
     */
    BudgetDTO getBudgetById(Long id, String email);
    
    /**
     * Creates a new budget for a user.
     * 
     * @param budgetDTO The budget data
     * @param email The email of the user
     * @return The created budget DTO
     */
    BudgetDTO createBudget(BudgetDTO budgetDTO, String email);
    
    /**
     * Updates an existing budget for a user.
     * 
     * @param budgetDTO The updated budget data
     * @param email The email of the user
     * @return The updated budget DTO
     */
    BudgetDTO updateBudget(BudgetDTO budgetDTO, String email);
    
    /**
     * Deletes a budget.
     * 
     * @param id The ID of the budget to delete
     * @param email The email of the user
     * @return true if the budget was deleted, false otherwise
     */
    boolean deleteBudget(Long id, String email);
    
    /**
     * Gets active budgets for a user.
     * 
     * @param email The email of the user
     * @return A list of active budget DTOs
     */
    List<BudgetDTO> getActiveBudgets(String email);
    
    /**
     * Gets active budgets for a specific category.
     * 
     * @param email The email of the user
     * @param categoryId The ID of the category
     * @return A list of active budget DTOs for the category
     */
    List<BudgetDTO> getActiveBudgetsByCategory(String email, Long categoryId);
    
    /**
     * Gets budgets that will expire soon.
     * 
     * @param email The email of the user
     * @param days The number of days to look ahead
     * @return A list of budget DTOs expiring within the specified days
     */
    List<BudgetDTO> getBudgetsExpiringSoon(String email, int days);
    
    /**
     * Checks if a budget is nearly depleted (≥90% used).
     * 
     * @param id The ID of the budget
     * @param email The email of the user
     * @return true if the budget is nearly depleted, false otherwise
     */
    boolean isBudgetNearlyDepleted(Long id, String email);
    
    /**
     * Gets the percentage of a budget that has been used.
     * 
     * @param id The ID of the budget
     * @param email The email of the user
     * @return The percentage of the budget used
     */
    int getBudgetUsagePercentage(Long id, String email);
}
