package com.expenseiq.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.expenseiq.dto.ExpenseDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.Category;
import com.expenseiq.model.Expense;
import com.expenseiq.model.User;
import com.expenseiq.repository.CategoryRepository;
import com.expenseiq.repository.ExpenseRepository;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.ExpenseService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the ExpenseService interface.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ExpenseServiceImpl implements ExpenseService {

    private final ExpenseRepository expenseRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;

    @Override
    public List<ExpenseDTO> getExpensesByUser(String email) {
        log.info("Getting all expenses for user: {}", email);
        User user = getUserByEmail(email);
        List<Expense> expenses = expenseRepository.findByUserId(user.getId());
        return expenses.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ExpenseDTO getExpenseById(Long id, String email) {
        log.info("Getting expense with ID: {} for user: {}", id, email);
        User user = getUserByEmail(email);
        Expense expense = expenseRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Expense not found with id: " + id + " for user: " + email));
        return mapToDTO(expense);
    }

    @Override
    @Transactional
    public ExpenseDTO createExpense(ExpenseDTO expenseDTO, String email) {
        log.info("Creating expense for user: {}", email);
        User user = getUserByEmail(email);
        
        Expense expense = new Expense();
        updateExpenseFromDTO(expense, expenseDTO, user);
        
        Expense savedExpense = expenseRepository.save(expense);
        log.info("Expense created with ID: {}", savedExpense.getId());
        
        return mapToDTO(savedExpense);
    }

    @Override
    @Transactional
    public ExpenseDTO updateExpense(ExpenseDTO expenseDTO, String email) {
        log.info("Updating expense with ID: {} for user: {}", expenseDTO.getId(), email);
        User user = getUserByEmail(email);
        
        Expense expense = expenseRepository.findByIdAndUserId(expenseDTO.getId(), user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Expense not found with id: " + expenseDTO.getId() + " for user: " + email));
        
        updateExpenseFromDTO(expense, expenseDTO, user);
        
        Expense updatedExpense = expenseRepository.save(expense);
        log.info("Expense updated with ID: {}", updatedExpense.getId());
        
        return mapToDTO(updatedExpense);
    }

    @Override
    @Transactional
    public boolean deleteExpense(Long id, String email) {
        log.info("Deleting expense with ID: {} for user: {}", id, email);
        User user = getUserByEmail(email);
        
        Expense expense = expenseRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Expense not found with id: " + id + " for user: " + email));
        
        expenseRepository.delete(expense);
        log.info("Expense deleted with ID: {}", id);
        
        return true;
    }

    @Override
    public List<ExpenseDTO> getExpensesByDateRange(String email, LocalDate startDate, LocalDate endDate) {
        log.info("Getting expenses for user: {} from {} to {}", email, startDate, endDate);
        User user = getUserByEmail(email);
        List<Expense> expenses = expenseRepository.findByUserIdAndDateBetween(user.getId(), startDate, endDate);
        return expenses.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Page<ExpenseDTO> getExpensesByDateRangePaginated(String email, LocalDate startDate, LocalDate endDate, 
                                                         int page, int size) {
        log.info("Getting paginated expenses for user: {} from {} to {}", email, startDate, endDate);
        User user = getUserByEmail(email);
        Pageable pageable = PageRequest.of(page, size, Sort.by("date").descending());
        Page<Expense> expensesPage = expenseRepository.findByUserIdAndDateBetween(
                user.getId(), startDate, endDate, pageable);
        
        return expensesPage.map(this::mapToDTO);
    }

    @Override
    public List<ExpenseDTO> getExpensesByCategory(String email, Long categoryId) {
        log.info("Getting expenses for user: {} in category: {}", email, categoryId);
        User user = getUserByEmail(email);
        List<Expense> expenses = expenseRepository.findByUserIdAndCategoryId(user.getId(), categoryId);
        return expenses.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public BigDecimal getTotalExpensesByDateRange(String email, LocalDate startDate, LocalDate endDate) {
        log.info("Getting total expenses for user: {} from {} to {}", email, startDate, endDate);
        User user = getUserByEmail(email);
        return expenseRepository.sumExpensesByDateRange(user.getId(), startDate, endDate);
    }

    @Override
    public Map<String, BigDecimal> getTotalExpensesByCategory(String email, LocalDate startDate, LocalDate endDate) {
        log.info("Getting total expenses by category for user: {} from {} to {}", email, startDate, endDate);
        User user = getUserByEmail(email);
        Map<String, BigDecimal> result = new HashMap<>();
        
        List<Object[]> data = expenseRepository.sumExpensesByCategory(user.getId(), startDate, endDate);
        for (Object[] row : data) {
            String categoryName = (String) row[0];
            BigDecimal amount = (BigDecimal) row[1];
            result.put(categoryName, amount);
        }
        
        return result;
    }

    @Override
    public List<ExpenseDTO> getRecentExpenses(String email, int limit) {
        log.info("Getting {} recent expenses for user: {}", limit, email);
        User user = getUserByEmail(email);
        Pageable pageable = PageRequest.of(0, limit);
        List<Expense> expenses = expenseRepository.findRecentExpenses(user.getId(), pageable);
        return expenses.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<ExpenseDTO> searchExpenses(String email, String searchTerm) {
        log.info("Searching expenses for user: {} with term: {}", email, searchTerm);
        User user = getUserByEmail(email);
        List<Expense> expenses = expenseRepository.searchByDescription(user.getId(), searchTerm);
        return expenses.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Maps an Expense entity to an ExpenseDTO.
     * 
     * @param expense The Expense entity
     * @return The ExpenseDTO
     */
    private ExpenseDTO mapToDTO(Expense expense) {
        ExpenseDTO dto = new ExpenseDTO();
        dto.setId(expense.getId());
        dto.setDescription(expense.getDescription());
        dto.setAmount(expense.getAmount());
        dto.setDate(expense.getDate());
        dto.setPaymentMethod(expense.getPaymentMethod());
        dto.setLocation(expense.getLocation());
        dto.setNotes(expense.getNotes());
        dto.setIsRecurring(expense.getIsRecurring());
        dto.setRecurringPeriod(expense.getRecurringPeriod());
        
        Category category = expense.getCategory();
        dto.setCategoryId(category.getId());
        dto.setCategoryName(category.getName());
        dto.setCategoryIcon(category.getIcon());
        dto.setCategoryColor(category.getColor());
        
        return dto;
    }

    /**
     * Updates an Expense entity from an ExpenseDTO.
     * 
     * @param expense The Expense entity to update
     * @param expenseDTO The ExpenseDTO with new values
     * @param user The associated User entity
     */
    private void updateExpenseFromDTO(Expense expense, ExpenseDTO expenseDTO, User user) {
        expense.setDescription(expenseDTO.getDescription());
        expense.setAmount(expenseDTO.getAmount());
        expense.setDate(expenseDTO.getDate());
        expense.setPaymentMethod(expenseDTO.getPaymentMethod());
        expense.setLocation(expenseDTO.getLocation());
        expense.setNotes(expenseDTO.getNotes());
        expense.setIsRecurring(expenseDTO.getIsRecurring());
        expense.setRecurringPeriod(expenseDTO.getRecurringPeriod());
        expense.setUser(user);
        
        Category category = categoryRepository.findByIdAndUserIdOrSystemDefault(
                expenseDTO.getCategoryId(), user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Category not found with id: " + expenseDTO.getCategoryId()));
        expense.setCategory(category);
    }

    /**
     * Gets a User by email.
     * 
     * @param email The email of the user
     * @return The User entity
     * @throws ResourceNotFoundException if the user is not found
     */
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }
}
