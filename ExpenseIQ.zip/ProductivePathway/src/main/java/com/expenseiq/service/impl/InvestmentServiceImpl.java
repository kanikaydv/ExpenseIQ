package com.expenseiq.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.expenseiq.dto.InsightDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.User;
import com.expenseiq.repository.ExpenseRepository;
import com.expenseiq.repository.IncomeRepository;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.InvestmentService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the InvestmentService interface.
 * 
 * This service generates investment suggestions based on user financial data.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class InvestmentServiceImpl implements InvestmentService {

    private final UserRepository userRepository;
    private final IncomeRepository incomeRepository;
    private final ExpenseRepository expenseRepository;

    @Override
    public List<InsightDTO> getInvestmentSuggestions(String email) {
        log.info("Getting investment suggestions for user: {}", email);
        
        List<InsightDTO> insights = new ArrayList<>();
        
        // Add personalized recommendations
        insights.addAll(getPersonalizedRecommendations(email));
        
        // Add savings rate analysis
        insights.add(getSavingsRateAnalysis(email));
        
        // Add diversification recommendations
        insights.addAll(getDiversificationRecommendations(email));
        
        return insights;
    }

    @Override
    public List<InsightDTO> getPersonalizedRecommendations(String email) {
        log.info("Getting personalized investment recommendations for user: {}", email);
        
        List<InsightDTO> insights = new ArrayList<>();
        
        // Create a basic recommendation
        InsightDTO recommendation = new InsightDTO();
        recommendation.setTitle("Investment Opportunity");
        recommendation.setDescription("Based on your savings pattern, consider investing in a low-cost index fund " +
                "to grow your wealth over time. Even small amounts can compound significantly.");
        recommendation.setType("investment-recommendation");
        recommendation.setIcon("trending_up");
        recommendation.setColor("#1976D2"); // Blue
        recommendation.setGeneratedDate(LocalDateTime.now());
        recommendation.setPriority(10);
        recommendation.setActionText("Learn More");
        recommendation.setActionUrl("https://www.investopedia.com/terms/i/indexfund.asp");
        
        insights.add(recommendation);
        
        // Add emergency fund recommendation
        InsightDTO emergencyFund = new InsightDTO();
        emergencyFund.setTitle("Emergency Fund");
        emergencyFund.setDescription("Before investing aggressively, ensure you have an emergency fund covering " +
                "3-6 months of expenses in a high-yield savings account.");
        emergencyFund.setType("investment-recommendation");
        emergencyFund.setIcon("account_balance");
        emergencyFund.setColor("#2E7D32"); // Green
        emergencyFund.setGeneratedDate(LocalDateTime.now());
        emergencyFund.setPriority(11);
        
        insights.add(emergencyFund);
        
        return insights;
    }

    @Override
    public InsightDTO getSavingsRateAnalysis(String email) {
        log.info("Getting savings rate analysis for user: {}", email);
        
        User user = getUserByEmail(email);
        
        // Calculate savings rate over the last 6 months
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusMonths(6);
        
        BigDecimal totalIncome = incomeRepository.sumIncomesByDateRange(
                user.getId(), startDate, endDate);
        BigDecimal totalExpenses = expenseRepository.sumExpensesByDateRange(
                user.getId(), startDate, endDate);
        BigDecimal savings = totalIncome.subtract(totalExpenses);
        
        InsightDTO savingsRateInsight = new InsightDTO();
        savingsRateInsight.setTitle("Savings Rate Analysis");
        savingsRateInsight.setType("savings-analysis");
        savingsRateInsight.setIcon("savings");
        savingsRateInsight.setCurrentValue(savings);
        savingsRateInsight.setGeneratedDate(LocalDateTime.now());
        savingsRateInsight.setPriority(12);
        
        if (totalIncome.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal savingsRate = savings.multiply(new BigDecimal("100"))
                    .divide(totalIncome, 2, RoundingMode.HALF_UP);
            
            savingsRateInsight.setChangePercentage(savingsRate);
            
            if (savingsRate.compareTo(new BigDecimal("20")) >= 0) {
                savingsRateInsight.setDescription("Great job! Your current savings rate is " + savingsRate + 
                        "%. This is an excellent foundation for your investment strategy.");
                savingsRateInsight.setColor("#2E7D32"); // Green
            } else if (savingsRate.compareTo(new BigDecimal("10")) >= 0) {
                savingsRateInsight.setDescription("Your current savings rate is " + savingsRate + 
                        "%. This is a good start, but try to increase it to 20% for optimal financial health.");
                savingsRateInsight.setColor("#1976D2"); // Blue
            } else if (savingsRate.compareTo(BigDecimal.ZERO) >= 0) {
                savingsRateInsight.setDescription("Your current savings rate is " + savingsRate + 
                        "%. Consider reducing expenses to increase this rate to at least 10%.");
                savingsRateInsight.setColor("#FF9800"); // Orange
            } else {
                savingsRateInsight.setDescription("Your expenses exceed your income, resulting in a negative " +
                        "savings rate. Focus on reducing expenses before investing.");
                savingsRateInsight.setColor("#FF0000"); // Red
            }
        } else {
            savingsRateInsight.setDescription("Insufficient income data to calculate your savings rate. " +
                    "Please ensure your income records are up to date.");
            savingsRateInsight.setColor("#1976D2"); // Blue
        }
        
        return savingsRateInsight;
    }

    @Override
    public List<InsightDTO> getDiversificationRecommendations(String email) {
        log.info("Getting diversification recommendations for user: {}", email);
        
        List<InsightDTO> insights = new ArrayList<>();
        
        // Diversification recommendation
        InsightDTO diversification = new InsightDTO();
        diversification.setTitle("Portfolio Diversification");
        diversification.setDescription("Consider a diversified portfolio with a mix of stocks, bonds, and " +
                "alternative investments to reduce risk while maintaining growth potential.");
        diversification.setType("investment-recommendation");
        diversification.setIcon("pie_chart");
        diversification.setColor("#1976D2"); // Blue
        diversification.setGeneratedDate(LocalDateTime.now());
        diversification.setPriority(13);
        
        insights.add(diversification);
        
        // Tax-advantaged accounts recommendation
        InsightDTO taxAdvantaged = new InsightDTO();
        taxAdvantaged.setTitle("Tax-Advantaged Investing");
        taxAdvantaged.setDescription("Maximize contributions to tax-advantaged retirement accounts like " +
                "401(k) or IRA before investing in taxable accounts.");
        taxAdvantaged.setType("investment-recommendation");
        taxAdvantaged.setIcon("account_balance");
        taxAdvantaged.setColor("#2E7D32"); // Green
        taxAdvantaged.setGeneratedDate(LocalDateTime.now());
        taxAdvantaged.setPriority(14);
        
        insights.add(taxAdvantaged);
        
        return insights;
    }

    @Override
    public List<InsightDTO> getRetirementPlanningInsights(String email) {
        log.info("Getting retirement planning insights for user: {}", email);
        
        List<InsightDTO> insights = new ArrayList<>();
        
        // Retirement savings recommendation
        InsightDTO retirement = new InsightDTO();
        retirement.setTitle("Retirement Planning");
        retirement.setDescription("To maintain your current lifestyle in retirement, aim to save at least " +
                "15% of your income specifically for retirement.");
        retirement.setType("retirement-insight");
        retirement.setIcon("elderly");
        retirement.setColor("#1976D2"); // Blue
        retirement.setGeneratedDate(LocalDateTime.now());
        retirement.setPriority(15);
        
        insights.add(retirement);
        
        // Compound interest example
        InsightDTO compoundInterest = new InsightDTO();
        compoundInterest.setTitle("Power of Compound Interest");
        compoundInterest.setDescription("If you invest $200 monthly with a 7% annual return, you could " +
                "have over $240,000 in 30 years due to compound interest.");
        compoundInterest.setType("retirement-insight");
        compoundInterest.setIcon("auto_graph");
        compoundInterest.setColor("#2E7D32"); // Green
        compoundInterest.setGeneratedDate(LocalDateTime.now());
        compoundInterest.setPriority(16);
        
        insights.add(compoundInterest);
        
        return insights;
    }

    /**
     * Gets a User by email.
     * 
     * @param email The email of the user
     * @return The User entity
     * @throws ResourceNotFoundException if the user is not found
     */
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }
}
