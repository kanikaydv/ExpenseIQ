package com.expenseiq.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.expenseiq.dto.CategoryDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.Category;
import com.expenseiq.model.User;
import com.expenseiq.repository.CategoryRepository;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.CategoryService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the CategoryService interface.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;

    @Override
    public List<CategoryDTO> getAllCategories() {
        log.info("Getting all categories");
        List<Category> categories = categoryRepository.findAll();
        return categories.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<CategoryDTO> getExpenseCategories() {
        log.info("Getting expense categories");
        List<Category> categories = categoryRepository.findByType("EXPENSE");
        return categories.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<CategoryDTO> getIncomeCategories() {
        log.info("Getting income categories");
        List<Category> categories = categoryRepository.findByType("INCOME");
        return categories.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CategoryDTO getCategoryById(Long id) {
        log.info("Getting category with ID: {}", id);
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + id));
        return mapToDTO(category);
    }

    @Override
    @Transactional
    public CategoryDTO createCategory(CategoryDTO categoryDTO, String email) {
        log.info("Creating category for user: {}", email);
        User user = getUserByEmail(email);
        
        // Check if name already exists for user
        if (categoryRepository.existsByNameAndUserId(categoryDTO.getName(), user.getId())) {
            throw new IllegalArgumentException("Category with name '" + categoryDTO.getName() + "' already exists");
        }
        
        Category category = new Category();
        updateCategoryFromDTO(category, categoryDTO);
        category.setUser(user);
        
        Category savedCategory = categoryRepository.save(category);
        log.info("Category created with ID: {}", savedCategory.getId());
        
        return mapToDTO(savedCategory);
    }

    @Override
    @Transactional
    public CategoryDTO updateCategory(CategoryDTO categoryDTO, String email) {
        log.info("Updating category with ID: {} for user: {}", categoryDTO.getId(), email);
        User user = getUserByEmail(email);
        
        Category category = categoryRepository.findByIdAndUserIdOrSystemDefault(
                categoryDTO.getId(), user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Category not found with id: " + categoryDTO.getId()));
        
        // Check if this is a system category (can't be modified)
        if (category.isSystemCategory()) {
            throw new IllegalArgumentException("System categories cannot be modified");
        }
        
        // Check if name already exists for another category
        if (!category.getName().equals(categoryDTO.getName()) && 
                categoryRepository.existsByNameAndUserId(categoryDTO.getName(), user.getId())) {
            throw new IllegalArgumentException("Category with name '" + categoryDTO.getName() + "' already exists");
        }
        
        updateCategoryFromDTO(category, categoryDTO);
        
        Category updatedCategory = categoryRepository.save(category);
        log.info("Category updated with ID: {}", updatedCategory.getId());
        
        return mapToDTO(updatedCategory);
    }

    @Override
    @Transactional
    public boolean deleteCategory(Long id, String email) {
        log.info("Deleting category with ID: {} for user: {}", id, email);
        User user = getUserByEmail(email);
        
        Category category = categoryRepository.findByIdAndUserIdOrSystemDefault(
                id, user.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Category not found with id: " + id));
        
        // Check if this is a system category (can't be deleted)
        if (category.isSystemCategory()) {
            throw new IllegalArgumentException("System categories cannot be deleted");
        }
        
        // Check if this is a default category (can't be deleted)
        if (category.isDefault()) {
            throw new IllegalArgumentException("Default categories cannot be deleted");
        }
        
        categoryRepository.delete(category);
        log.info("Category deleted with ID: {}", id);
        
        return true;
    }

    @Override
    public List<CategoryDTO> getCustomCategories(String email) {
        log.info("Getting custom categories for user: {}", email);
        User user = getUserByEmail(email);
        
        List<Category> categories = categoryRepository.findAllByUserIdOrSystemDefault(user.getId())
                .stream()
                .filter(c -> c.getUser() != null && c.getUser().getId().equals(user.getId()))
                .collect(Collectors.toList());
        
        return categories.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<CategoryDTO> getSystemCategories() {
        log.info("Getting system categories");
        
        List<Category> categories = categoryRepository.findAll()
                .stream()
                .filter(c -> c.getUser() == null)
                .collect(Collectors.toList());
        
        return categories.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public boolean existsByName(String name, String email) {
        log.info("Checking if category exists with name: {} for user: {}", name, email);
        User user = getUserByEmail(email);
        return categoryRepository.existsByNameAndUserId(name, user.getId());
    }

    /**
     * Maps a Category entity to a CategoryDTO.
     * 
     * @param category The Category entity
     * @return The CategoryDTO
     */
    private CategoryDTO mapToDTO(Category category) {
        CategoryDTO dto = new CategoryDTO();
        dto.setId(category.getId());
        dto.setName(category.getName());
        dto.setDescription(category.getDescription());
        dto.setIcon(category.getIcon());
        dto.setType(category.getType());
        dto.setDefault(category.isDefault());
        dto.setColor(category.getColor());
        return dto;
    }

    /**
     * Updates a Category entity from a CategoryDTO.
     * 
     * @param category The Category entity to update
     * @param categoryDTO The CategoryDTO with new values
     */
    private void updateCategoryFromDTO(Category category, CategoryDTO categoryDTO) {
        category.setName(categoryDTO.getName());
        category.setDescription(categoryDTO.getDescription());
        category.setIcon(categoryDTO.getIcon());
        category.setType(categoryDTO.getType());
        category.setDefault(categoryDTO.isDefault());
        category.setColor(categoryDTO.getColor());
    }

    /**
     * Gets a User by email.
     * 
     * @param email The email of the user
     * @return The User entity
     * @throws ResourceNotFoundException if the user is not found
     */
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }
}
