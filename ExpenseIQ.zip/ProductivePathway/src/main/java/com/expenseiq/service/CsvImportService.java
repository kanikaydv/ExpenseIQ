package com.expenseiq.service;

import org.springframework.web.multipart.MultipartFile;

/**
 * Service interface for CSV import operations.
 * 
 * This interface defines methods for importing data from CSV files.
 */
public interface CsvImportService {
    
    /**
     * Imports expenses from a CSV file.
     * 
     * @param file The uploaded CSV file
     * @param email The email of the user
     * @return The number of expenses imported
     * @throws Exception If an error occurs during import
     */
    int importExpensesFromCSV(MultipartFile file, String email) throws Exception;
    
    /**
     * Imports incomes from a CSV file.
     * 
     * @param file The uploaded CSV file
     * @param email The email of the user
     * @return The number of incomes imported
     * @throws Exception If an error occurs during import
     */
    int importIncomesFromCSV(MultipartFile file, String email) throws Exception;
    
    /**
     * Validates a CSV file.
     * 
     * @param file The file to validate
     * @return true if the file is valid, false otherwise
     */
    boolean validateCSVFile(MultipartFile file);
}
