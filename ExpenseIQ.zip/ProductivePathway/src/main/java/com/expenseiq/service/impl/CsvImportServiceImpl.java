package com.expenseiq.service.impl;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.expenseiq.dto.ExpenseDTO;
import com.expenseiq.dto.IncomeDTO;
import com.expenseiq.exception.ResourceNotFoundException;
import com.expenseiq.model.Category;
import com.expenseiq.model.User;
import com.expenseiq.repository.CategoryRepository;
import com.expenseiq.repository.UserRepository;
import com.expenseiq.service.CsvImportService;
import com.expenseiq.service.ExpenseService;
import com.expenseiq.service.IncomeService;
import com.expenseiq.util.CSVHelper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Implementation of the CsvImportService interface.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class CsvImportServiceImpl implements CsvImportService {

    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final ExpenseService expenseService;
    private final IncomeService incomeService;
    private final CSVHelper csvHelper;

    @Override
    @Transactional
    public int importExpensesFromCSV(MultipartFile file, String email) throws Exception {
        log.info("Importing expenses from CSV for user: {}", email);
        
        if (!validateCSVFile(file)) {
            throw new IllegalArgumentException("Invalid CSV file. Please check the file format.");
        }
        
        User user = getUserByEmail(email);
        List<ExpenseDTO> expenses = new ArrayList<>();
        Map<String, Long> categoryCache = new HashMap<>();
        
        try (Reader reader = new InputStreamReader(file.getInputStream());
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            for (CSVRecord csvRecord : csvParser) {
                try {
                    ExpenseDTO expense = parseExpenseRecord(csvRecord, user, categoryCache);
                    expenses.add(expense);
                } catch (Exception e) {
                    log.warn("Skipping invalid record: {}", csvRecord.toString(), e);
                }
            }
        } catch (IOException e) {
            log.error("Failed to parse CSV file", e);
            throw new Exception("Failed to parse CSV file: " + e.getMessage());
        }
        
        int importCount = 0;
        for (ExpenseDTO expense : expenses) {
            try {
                expenseService.createExpense(expense, email);
                importCount++;
            } catch (Exception e) {
                log.warn("Failed to import expense: {}", expense, e);
            }
        }
        
        log.info("Successfully imported {} expenses for user: {}", importCount, email);
        return importCount;
    }

    @Override
    @Transactional
    public int importIncomesFromCSV(MultipartFile file, String email) throws Exception {
        log.info("Importing incomes from CSV for user: {}", email);
        
        if (!validateCSVFile(file)) {
            throw new IllegalArgumentException("Invalid CSV file. Please check the file format.");
        }
        
        User user = getUserByEmail(email);
        List<IncomeDTO> incomes = new ArrayList<>();
        Map<String, Long> categoryCache = new HashMap<>();
        
        try (Reader reader = new InputStreamReader(file.getInputStream());
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            for (CSVRecord csvRecord : csvParser) {
                try {
                    IncomeDTO income = parseIncomeRecord(csvRecord, user, categoryCache);
                    incomes.add(income);
                } catch (Exception e) {
                    log.warn("Skipping invalid record: {}", csvRecord.toString(), e);
                }
            }
        } catch (IOException e) {
            log.error("Failed to parse CSV file", e);
            throw new Exception("Failed to parse CSV file: " + e.getMessage());
        }
        
        int importCount = 0;
        for (IncomeDTO income : incomes) {
            try {
                incomeService.createIncome(income, email);
                importCount++;
            } catch (Exception e) {
                log.warn("Failed to import income: {}", income, e);
            }
        }
        
        log.info("Successfully imported {} incomes for user: {}", importCount, email);
        return importCount;
    }

    @Override
    public boolean validateCSVFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return false;
        }
        
        String filename = file.getOriginalFilename();
        return filename != null && (filename.endsWith(".csv") || filename.endsWith(".CSV"));
    }

    /**
     * Parses a CSV record into an ExpenseDTO.
     * 
     * @param csvRecord The CSV record
     * @param user The User entity
     * @param categoryCache A cache of category names to IDs
     * @return The parsed ExpenseDTO
     */
    private ExpenseDTO parseExpenseRecord(CSVRecord csvRecord, User user, Map<String, Long> categoryCache) {
        ExpenseDTO expenseDTO = new ExpenseDTO();
        
        // Required fields
        expenseDTO.setDescription(csvRecord.get("Description"));
        expenseDTO.setAmount(csvHelper.parseAmount(csvRecord.get("Amount")));
        expenseDTO.setDate(parseDate(csvRecord.get("Date")));
        
        // Category
        String categoryName = csvRecord.get("Category");
        Long categoryId = findOrCreateCategory(categoryName, "EXPENSE", user, categoryCache);
        expenseDTO.setCategoryId(categoryId);
        
        // Optional fields
        if (csvRecord.isMapped("Payment Method")) {
            expenseDTO.setPaymentMethod(csvRecord.get("Payment Method"));
        }
        
        if (csvRecord.isMapped("Location")) {
            expenseDTO.setLocation(csvRecord.get("Location"));
        }
        
        if (csvRecord.isMapped("Notes")) {
            expenseDTO.setNotes(csvRecord.get("Notes"));
        }
        
        if (csvRecord.isMapped("Recurring")) {
            expenseDTO.setIsRecurring(Boolean.parseBoolean(csvRecord.get("Recurring")));
        }
        
        if (csvRecord.isMapped("Recurring Period")) {
            expenseDTO.setRecurringPeriod(csvRecord.get("Recurring Period"));
        }
        
        return expenseDTO;
    }

    /**
     * Parses a CSV record into an IncomeDTO.
     * 
     * @param csvRecord The CSV record
     * @param user The User entity
     * @param categoryCache A cache of category names to IDs
     * @return The parsed IncomeDTO
     */
    private IncomeDTO parseIncomeRecord(CSVRecord csvRecord, User user, Map<String, Long> categoryCache) {
        IncomeDTO incomeDTO = new IncomeDTO();
        
        // Required fields
        incomeDTO.setDescription(csvRecord.get("Description"));
        incomeDTO.setAmount(csvHelper.parseAmount(csvRecord.get("Amount")));
        incomeDTO.setDate(parseDate(csvRecord.get("Date")));
        
        // Category
        String categoryName = csvRecord.get("Category");
        Long categoryId = findOrCreateCategory(categoryName, "INCOME", user, categoryCache);
        incomeDTO.setCategoryId(categoryId);
        
        // Optional fields
        if (csvRecord.isMapped("Source")) {
            incomeDTO.setSource(csvRecord.get("Source"));
        }
        
        if (csvRecord.isMapped("Notes")) {
            incomeDTO.setNotes(csvRecord.get("Notes"));
        }
        
        if (csvRecord.isMapped("Recurring")) {
            incomeDTO.setIsRecurring(Boolean.parseBoolean(csvRecord.get("Recurring")));
        }
        
        if (csvRecord.isMapped("Recurring Period")) {
            incomeDTO.setRecurringPeriod(csvRecord.get("Recurring Period"));
        }
        
        return incomeDTO;
    }

    /**
     * Parses a date string into a LocalDate.
     * 
     * @param dateStr The date string
     * @return The parsed LocalDate
     */
    private LocalDate parseDate(String dateStr) {
        // Try different date formats
        DateTimeFormatter[] formatters = {
            DateTimeFormatter.ISO_LOCAL_DATE,
            DateTimeFormatter.ofPattern("MM/dd/yyyy"),
            DateTimeFormatter.ofPattern("MM-dd-yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd")
        };
        
        for (DateTimeFormatter formatter : formatters) {
            try {
                return LocalDate.parse(dateStr, formatter);
            } catch (DateTimeParseException e) {
                // Try next format
            }
        }
        
        // Default to today if no format matches
        log.warn("Could not parse date '{}', using current date instead", dateStr);
        return LocalDate.now();
    }

    /**
     * Finds or creates a category by name.
     * 
     * @param categoryName The name of the category
     * @param type The type of category (EXPENSE or INCOME)
     * @param user The User entity
     * @param categoryCache A cache of category names to IDs
     * @return The ID of the category
     */
    private Long findOrCreateCategory(String categoryName, String type, User user, Map<String, Long> categoryCache) {
        // Check cache first
        if (categoryCache.containsKey(categoryName)) {
            return categoryCache.get(categoryName);
        }
        
        // Look for existing category (system or user-specific)
        Optional<Category> categoryOpt = categoryRepository.findByNameAndUserId(categoryName, user.getId());
        
        if (categoryOpt.isPresent()) {
            Long categoryId = categoryOpt.get().getId();
            categoryCache.put(categoryName, categoryId);
            return categoryId;
        }
        
        // Create new category
        Category category = new Category();
        category.setName(categoryName);
        category.setType(type);
        category.setUser(user);
        category.setDefault(false);
        
        Category savedCategory = categoryRepository.save(category);
        Long categoryId = savedCategory.getId();
        categoryCache.put(categoryName, categoryId);
        return categoryId;
    }

    /**
     * Gets a User by email.
     * 
     * @param email The email of the user
     * @return The User entity
     * @throws ResourceNotFoundException if the user is not found
     */
    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }
}
