package com.expenseiq.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;

/**
 * Utility class for CSV file operations.
 * 
 * This class provides helper methods for parsing and validating CSV files.
 */
@Component
@Slf4j
public class CSVHelper {

    private static final String CSV_TYPE = "text/csv";
    private static final List<String> EXPENSE_HEADERS = Arrays.asList(
            "Description", "Amount", "Date", "Category");
    private static final List<String> INCOME_HEADERS = Arrays.asList(
            "Description", "Amount", "Date", "Category");

    /**
     * Validates if a file is a CSV file.
     * 
     * @param file The file to validate
     * @return true if the file is a valid CSV file, false otherwise
     */
    public boolean isCSVFile(MultipartFile file) {
        return CSV_TYPE.equals(file.getContentType()) || 
                (file.getOriginalFilename() != null && file.getOriginalFilename().endsWith(".csv"));
    }

    /**
     * Validates if a CSV file has the required headers for expenses.
     * 
     * @param file The CSV file to validate
     * @return true if the file has valid expense headers, false otherwise
     */
    public boolean hasValidExpenseHeaders(MultipartFile file) {
        try (BufferedReader fileReader = new BufferedReader(
                new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8));
             CSVParser parser = new CSVParser(fileReader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            return EXPENSE_HEADERS.stream()
                    .allMatch(header -> parser.getHeaderMap().containsKey(header));
            
        } catch (IOException e) {
            log.error("Failed to parse CSV file", e);
            return false;
        }
    }

    /**
     * Validates if a CSV file has the required headers for incomes.
     * 
     * @param file The CSV file to validate
     * @return true if the file has valid income headers, false otherwise
     */
    public boolean hasValidIncomeHeaders(MultipartFile file) {
        try (BufferedReader fileReader = new BufferedReader(
                new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8));
             CSVParser parser = new CSVParser(fileReader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            return INCOME_HEADERS.stream()
                    .allMatch(header -> parser.getHeaderMap().containsKey(header));
            
        } catch (IOException e) {
            log.error("Failed to parse CSV file", e);
            return false;
        }
    }

    /**
     * Parses a string amount to a BigDecimal.
     * 
     * @param amountStr The amount string
     * @return The parsed BigDecimal
     */
    public BigDecimal parseAmount(String amountStr) {
        String cleaned = amountStr.replaceAll("[^\\d.-]", "");
        return new BigDecimal(cleaned);
    }

    /**
     * Parses a date string to a LocalDate.
     * 
     * @param dateStr The date string
     * @return The parsed LocalDate, or current date if parsing fails
     */
    public LocalDate parseDate(String dateStr) {
        // Try different date formats
        DateTimeFormatter[] formatters = {
            DateTimeFormatter.ISO_LOCAL_DATE,
            DateTimeFormatter.ofPattern("MM/dd/yyyy"),
            DateTimeFormatter.ofPattern("MM-dd-yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd")
        };
        
        for (DateTimeFormatter formatter : formatters) {
            try {
                return LocalDate.parse(dateStr, formatter);
            } catch (DateTimeParseException e) {
                // Try next format
            }
        }
        
        // Default to today if no format matches
        log.warn("Could not parse date '{}', using current date instead", dateStr);
        return LocalDate.now();
    }

    /**
     * Gets all records from a CSV file.
     * 
     * @param is The input stream of the CSV file
     * @return A list of CSV records
     */
    public List<CSVRecord> getRecords(InputStream is) {
        try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
             CSVParser csvParser = new CSVParser(fileReader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            return new ArrayList<>(csvParser.getRecords());
            
        } catch (IOException e) {
            log.error("Failed to parse CSV file", e);
            throw new RuntimeException("Failed to parse CSV file: " + e.getMessage());
        }
    }
}
