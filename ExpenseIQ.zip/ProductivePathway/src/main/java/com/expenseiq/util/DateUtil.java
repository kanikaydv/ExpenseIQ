package com.expenseiq.util;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

/**
 * Utility class for date operations.
 * 
 * This class provides helper methods for common date operations.
 */
@Component
public class DateUtil {

    /**
     * Gets the start date of a month.
     * 
     * @param year The year
     * @param month The month (1-12)
     * @return The first date of the month
     */
    public LocalDate getMonthStart(int year, int month) {
        return LocalDate.of(year, month, 1);
    }

    /**
     * Gets the end date of a month.
     * 
     * @param year The year
     * @param month The month (1-12)
     * @return The last date of the month
     */
    public LocalDate getMonthEnd(int year, int month) {
        return LocalDate.of(year, month, 1).with(TemporalAdjusters.lastDayOfMonth());
    }

    /**
     * Gets the start date of a year.
     * 
     * @param year The year
     * @return The first date of the year
     */
    public LocalDate getYearStart(int year) {
        return LocalDate.of(year, 1, 1);
    }

    /**
     * Gets the end date of a year.
     * 
     * @param year The year
     * @return The last date of the year
     */
    public LocalDate getYearEnd(int year) {
        return LocalDate.of(year, 12, 31);
    }

    /**
     * Gets the start and end dates for a period.
     * 
     * @param period The period (month, quarter, year, all)
     * @param date The reference date
     * @return An array with the start date and end date
     */
    public LocalDate[] getPeriodDates(String period, LocalDate date) {
        LocalDate startDate;
        LocalDate endDate;
        
        switch (period.toLowerCase()) {
            case "month":
                startDate = date.withDayOfMonth(1);
                endDate = date.with(TemporalAdjusters.lastDayOfMonth());
                break;
            case "quarter":
                int quarter = (date.getMonthValue() - 1) / 3 + 1;
                startDate = LocalDate.of(date.getYear(), (quarter - 1) * 3 + 1, 1);
                endDate = LocalDate.of(date.getYear(), quarter * 3, 1)
                        .with(TemporalAdjusters.lastDayOfMonth());
                break;
            case "year":
                startDate = LocalDate.of(date.getYear(), 1, 1);
                endDate = LocalDate.of(date.getYear(), 12, 31);
                break;
            case "all":
                startDate = LocalDate.of(date.getYear() - 5, 1, 1); // 5 years back
                endDate = date;
                break;
            default:
                throw new IllegalArgumentException("Invalid period: " + period);
        }
        
        return new LocalDate[] { startDate, endDate };
    }

    /**
     * Gets the days between two dates.
     * 
     * @param startDate The start date
     * @param endDate The end date
     * @return The number of days between the dates
     */
    public long daysBetween(LocalDate startDate, LocalDate endDate) {
        return ChronoUnit.DAYS.between(startDate, endDate);
    }

    /**
     * Gets a list of months between two dates.
     * 
     * @param startDate The start date
     * @param endDate The end date
     * @return A list of dates representing the first day of each month
     */
    public List<LocalDate> getMonthsBetween(LocalDate startDate, LocalDate endDate) {
        List<LocalDate> months = new ArrayList<>();
        
        LocalDate date = startDate.withDayOfMonth(1);
        while (!date.isAfter(endDate)) {
            months.add(date);
            date = date.plusMonths(1);
        }
        
        return months;
    }

    /**
     * Checks if a date is within a date range.
     * 
     * @param date The date to check
     * @param startDate The start of the range
     * @param endDate The end of the range
     * @return true if the date is within the range, false otherwise
     */
    public boolean isDateInRange(LocalDate date, LocalDate startDate, LocalDate endDate) {
        return !date.isBefore(startDate) && !date.isAfter(endDate);
    }

    /**
     * Gets the current month and year as a string.
     * 
     * @return The current month and year (e.g., "January 2023")
     */
    public String getCurrentMonthYear() {
        LocalDate now = LocalDate.now();
        return now.getMonth().toString() + " " + now.getYear();
    }
}
