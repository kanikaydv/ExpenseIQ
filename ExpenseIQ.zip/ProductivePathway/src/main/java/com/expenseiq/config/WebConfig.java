package com.expenseiq.config;

import java.util.Locale;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

/**
 * Web configuration for the ExpenseIQ application.
 * 
 * This class configures web-specific features such as locale settings,
 * resource handlers, and default view controllers.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * Configures locale resolver for internationalization support.
     * 
     * @return A SessionLocaleResolver with default locale set to US
     */
    @Bean
    public LocaleResolver localeResolver() {
        SessionLocaleResolver resolver = new SessionLocaleResolver();
        resolver.setDefaultLocale(Locale.US);
        return resolver;
    }

    /**
     * Configures locale change interceptor to switch languages dynamically.
     * 
     * @return A LocaleChangeInterceptor configured to use 'lang' parameter
     */
    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor() {
        LocaleChangeInterceptor interceptor = new LocaleChangeInterceptor();
        interceptor.setParamName("lang");
        return interceptor;
    }

    /**
     * Registers the locale change interceptor.
     * 
     * @param registry The InterceptorRegistry to add interceptors to
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(localeChangeInterceptor());
    }

    /**
     * Configures resource handlers for static resources.
     * 
     * @param registry The ResourceHandlerRegistry to add handlers to
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/static/");
    }

    /**
     * Configures simple view controllers for basic mappings.
     * 
     * @param registry The ViewControllerRegistry to add controllers to
     */
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        // Root URL is now handled by HomeController
        registry.addViewController("/auth/login").setViewName("auth/login");
        registry.addViewController("/auth/register").setViewName("auth/register");
    }
}
