package com.expenseiq.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import lombok.RequiredArgsConstructor;

/**
 * Security configuration for the ExpenseIQ application.
 * 
 * This class configures Spring Security with custom authentication, 
 * authorization rules, and password encryption.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    // No need for these fields as we're using method injection in authenticationManager

    /**
     * Configures security rules for HTTP requests.
     * 
     * @param http The HttpSecurity to configure
     * @return The configured SecurityFilterChain
     * @throws Exception If an error occurs during configuration
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF for simplicity in the demo
            .csrf(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(auth -> auth
                // Make everything public for the demo
                .anyRequest().permitAll()
            )
            // Disable form login
            .formLogin(AbstractHttpConfigurer::disable)
            // Disable HTTP Basic
            .httpBasic(AbstractHttpConfigurer::disable)
            // Simple logout configuration
            .logout(logout -> logout
                .logoutRequestMatcher(new AntPathRequestMatcher("/auth/logout"))
                .logoutSuccessUrl("/")
                .permitAll()
            );
        
        return http.build();
    }

    /**
     * Configures the authentication manager with a custom user details service.
     * 
     * @param http The HttpSecurity to configure
     * @param userDetailsService The user details service to use
     * @param passwordEncoder The password encoder to use
     * @return The configured AuthenticationManager
     * @throws Exception If an error occurs during configuration
     */
    @Bean
    public static AuthenticationManager authenticationManager(
            HttpSecurity http, 
            UserDetailsService userDetailsService,
            PasswordEncoder passwordEncoder) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class)
            .userDetailsService(userDetailsService)
            .passwordEncoder(passwordEncoder)
            .and()
            .build();
    }
}
