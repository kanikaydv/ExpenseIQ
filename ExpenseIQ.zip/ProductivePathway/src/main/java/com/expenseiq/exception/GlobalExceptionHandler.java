package com.expenseiq.exception;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

/**
 * Global exception handler for the ExpenseIQ application.
 * 
 * This class handles exceptions thrown throughout the application,
 * providing appropriate error responses and logging.
 */
@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * Handles ResourceNotFoundException by returning a 404 Not Found response.
     * 
     * @param e The exception
     * @param model The model to add attributes to
     * @param request The HTTP request
     * @return The name of the error view
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String handleResourceNotFoundException(
            ResourceNotFoundException e, 
            Model model,
            HttpServletRequest request) {
        
        log.error("Resource not found: {}", e.getMessage());
        
        model.addAttribute("errorTitle", "Resource Not Found");
        model.addAttribute("errorMessage", e.getMessage());
        model.addAttribute("requestedUrl", request.getRequestURL());
        
        return "error/404";
    }

    /**
     * Handles AccessDeniedException by returning a 403 Forbidden response.
     * 
     * @param e The exception
     * @param model The model to add attributes to
     * @param request The HTTP request
     * @return The name of the error view
     */
    @ExceptionHandler(org.springframework.security.access.AccessDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public String handleAccessDeniedException(
            Exception e, 
            Model model,
            HttpServletRequest request) {
        
        log.error("Access denied: {}", e.getMessage());
        
        model.addAttribute("errorTitle", "Access Denied");
        model.addAttribute("errorMessage", "You don't have permission to access this resource.");
        model.addAttribute("requestedUrl", request.getRequestURL());
        
        return "error/403";
    }

    /**
     * Handles general exceptions by returning a 500 Internal Server Error response.
     * 
     * @param e The exception
     * @param model The model to add attributes to
     * @param request The HTTP request
     * @return The name of the error view
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleGenericException(
            Exception e, 
            Model model,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        
        log.error("Unhandled exception", e);
        
        // For AJAX requests, we might want to return JSON
        if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
            // Return a partial view or JSON response
            model.addAttribute("error", "An unexpected error occurred.");
            return "fragments/error :: message";
        }
        
        // For form submissions, add flash attributes and redirect
        String referer = request.getHeader("Referer");
        if (referer != null && referer.contains(request.getServerName())) {
            redirectAttributes.addFlashAttribute("error", "An unexpected error occurred: " + e.getMessage());
            return "redirect:" + referer;
        }
        
        // For regular requests, show the error page
        model.addAttribute("errorTitle", "Unexpected Error");
        model.addAttribute("errorMessage", "An unexpected error occurred. Please try again later.");
        model.addAttribute("exceptionMessage", e.getMessage());
        model.addAttribute("requestedUrl", request.getRequestURL());
        
        return "error/500";
    }
}
