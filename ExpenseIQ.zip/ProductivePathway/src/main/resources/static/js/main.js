/**
 * ExpenseIQ - Main JavaScript
 * 
 * This file contains all the client-side JavaScript functionality
 * for the ExpenseIQ application.
 */

// Initialize JavaScript functionality when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('ExpenseIQ JavaScript initialized');
    
    // Initialize all components
    initSidebar();
    initUserMenu();
    initAlerts();
    initDatePickers();
    initForms();
    initTooltips();
    initTables();
    
    // If on dashboard page, initialize dashboard-specific functionality
    if (document.querySelector('.dashboard-container')) {
        initDashboard();
    }
    
    // If on insights page, initialize insights-specific functionality
    if (document.querySelector('.insights-container')) {
        initInsights();
    }
    
    // If on budgets page, initialize budgets-specific functionality
    if (document.querySelector('.budgets-container')) {
        initBudgets();
    }
});

/**
 * Initialize sidebar functionality
 */
function initSidebar() {
    const sidebarToggleBtn = document.getElementById('sidebarToggle');
    if (sidebarToggleBtn) {
        sidebarToggleBtn.addEventListener('click', function() {
            document.body.classList.toggle('sidebar-toggled');
            document.querySelector('.sidebar').classList.toggle('toggled');
        });
    }
}

/**
 * Initialize user dropdown menu
 */
function initUserMenu() {
    const userDropdown = document.querySelector('.dropdown-toggle');
    if (userDropdown) {
        userDropdown.addEventListener('click', function(e) {
            e.preventDefault();
            const dropdown = document.querySelector('.dropdown-menu');
            dropdown.classList.toggle('show');
        });
    }
}

/**
 * Initialize alert messages
 */
function initAlerts() {
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        const closeBtn = alert.querySelector('.btn-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                alert.remove();
            });
        }
    });
}

/**
 * Initialize date picker inputs
 */
function initDatePickers() {
    const datePickers = document.querySelectorAll('.datepicker');
    datePickers.forEach(input => {
        if (typeof flatpickr !== 'undefined') {
            flatpickr(input, {
                dateFormat: 'Y-m-d'
            });
        }
    });
}

/**
 * Initialize form validation and submission
 */
function initForms() {
    // Handle Bootstrap validation forms
    const validationForms = document.querySelectorAll('.needs-validation');
    validationForms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
    
    // Special handling for login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        console.log('Login form detected, adding enhanced submission handling');
        
        loginForm.addEventListener('submit', function(event) {
            console.log('Login form submit triggered');
            const username = document.getElementById('username')?.value;
            const password = document.getElementById('password')?.value;
            
            // Log form data (without showing the actual password)
            console.log('Username provided:', username ? 'Yes' : 'No');
            console.log('Password provided:', password ? 'Yes' : 'No');
            
            if (!username || !password) {
                console.warn('Login validation failed - missing fields');
                event.preventDefault();
                alert('Please enter both email and password');
                return false;
            }
            
            console.log('Login form validation passed');
        });
    }
}

/**
 * Initialize tooltips
 */
function initTooltips() {
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(tooltip => {
        new bootstrap.Tooltip(tooltip);
    });
}

/**
 * Initialize responsive tables
 */
function initTables() {
    const tables = document.querySelectorAll('.table-responsive');
    tables.forEach(table => {
        console.log('Responsive table initialized');
    });
}

/**
 * Initialize dashboard functionality
 */
function initDashboard() {
    console.log('Dashboard page initialized');
    
    // Initialize charts if Chart.js is available
    if (typeof Chart !== 'undefined') {
        initDashboardCharts();
    }
}

/**
 * Initialize insights functionality
 */
function initInsights() {
    console.log('Insights page initialized');
    
    // Initialize charts if Chart.js is available
    if (typeof Chart !== 'undefined') {
        initInsightsCharts();
    }
}

/**
 * Initialize budgets functionality
 */
function initBudgets() {
    console.log('Budgets page initialized');
    
    const budgetForms = document.querySelectorAll('.budget-form');
    budgetForms.forEach(form => {
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            
            // Simple validation example
            const amount = form.querySelector('[name="amount"]').value;
            if (!amount || isNaN(amount) || parseFloat(amount) <= 0) {
                showNotification('Please enter a valid amount', 'error');
                return;
            }
            
            // In a real app, this would use fetch to submit the form via AJAX
            showNotification('Budget saved successfully', 'success');
        });
    });
}

/**
 * Format a date object to YYYY-MM-DD
 * @param {Date} date - Date object to format
 * @return {string} Formatted date string
 */
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * Format currency value
 * @param {number} value - Value to format
 * @param {string} currency - Currency code
 * @return {string} Formatted currency value
 */
function formatCurrency(value, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency
    }).format(value);
}

/**
 * Format percentage value
 * @param {number} value - Value to format
 * @return {string} Formatted percentage value
 */
function formatPercentage(value) {
    return new Intl.NumberFormat('en-US', {
        style: 'percent',
        minimumFractionDigits: 1,
        maximumFractionDigits: 1
    }).format(value / 100);
}

/**
 * Show loading indicator
 */
function showLoading() {
    const loader = document.createElement('div');
    loader.classList.add('loading-overlay');
    loader.innerHTML = '<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>';
    document.body.appendChild(loader);
}

/**
 * Hide loading indicator
 */
function hideLoading() {
    const loader = document.querySelector('.loading-overlay');
    if (loader) {
        loader.remove();
    }
}

/**
 * Show a notification
 * @param {string} message - Notification message
 * @param {string} type - Notification type: success, error, warning, info
 */
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.classList.add('toast', 'show', `bg-${type === 'error' ? 'danger' : type}`);
    notification.setAttribute('role', 'alert');
    notification.setAttribute('aria-live', 'assertive');
    notification.setAttribute('aria-atomic', 'true');
    
    notification.innerHTML = `
        <div class="toast-header">
            <strong class="me-auto">ExpenseIQ</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body text-white">
            ${message}
        </div>
    `;
    
    const container = document.querySelector('.toast-container');
    if (container) {
        container.appendChild(notification);
    } else {
        const newContainer = document.createElement('div');
        newContainer.classList.add('toast-container', 'position-fixed', 'bottom-0', 'end-0', 'p-3');
        newContainer.appendChild(notification);
        document.body.appendChild(newContainer);
    }
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 500);
    }, 5000);
}

/**
 * Confirm action with a dialog
 * @param {string} message - Confirmation message
 * @return {Promise} Resolves to true if confirmed, false otherwise
 */
function confirmAction(message) {
    return new Promise((resolve) => {
        if (confirm(message)) {
            resolve(true);
        } else {
            resolve(false);
        }
    });
}