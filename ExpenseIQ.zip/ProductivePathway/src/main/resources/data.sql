-- Insert default categories (only if they don't exist)
-- Expense categories
INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Food & Dining', 'Restaurants, groceries, and other food expenses', 'restaurant', 'EXPENSE', TRUE, '#FF9800'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Food & Dining' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Transportation', 'Public transport, fuel, car maintenance', 'directions_car', 'EXPENSE', TRUE, '#1976D2'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Transportation' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Housing', 'Rent, mortgage, utilities, home maintenance', 'home', 'EXPENSE', TRUE, '#2E7D32'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Housing' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Entertainment', 'Movies, events, hobbies', 'local_activity', 'EXPENSE', TRUE, '#9C27B0'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Entertainment' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Shopping', 'Clothing, electronics, general retail', 'shopping_bag', 'EXPENSE', TRUE, '#F44336'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Shopping' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Health & Medical', 'Healthcare, medicine, insurance', 'local_hospital', 'EXPENSE', TRUE, '#00BCD4'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Health & Medical' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Education', 'Tuition, books, courses', 'school', 'EXPENSE', TRUE, '#3F51B5'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Education' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Travel', 'Flights, hotels, vacations', 'flight', 'EXPENSE', TRUE, '#795548'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Travel' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Personal Care', 'Haircuts, grooming, spa', 'spa', 'EXPENSE', TRUE, '#E91E63'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Personal Care' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Gifts & Donations', 'Presents, charitable donations', 'card_giftcard', 'EXPENSE', TRUE, '#8BC34A'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Gifts & Donations' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Bills & Utilities', 'Internet, phone, electricity, water', 'receipt', 'EXPENSE', TRUE, '#FF5722'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Bills & Utilities' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Other Expenses', 'Miscellaneous expenses', 'more_horiz', 'EXPENSE', TRUE, '#607D8B'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Other Expenses' AND user_id IS NULL);

-- Income categories
INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Salary', 'Regular employment income', 'work', 'INCOME', TRUE, '#2E7D32'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Salary' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Freelance', 'Independent contractor work', 'computer', 'INCOME', TRUE, '#1976D2'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Freelance' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Investments', 'Dividends, capital gains, interest', 'trending_up', 'INCOME', TRUE, '#FF9800'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Investments' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Gifts', 'Money received as gifts', 'card_giftcard', 'INCOME', TRUE, '#9C27B0'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Gifts' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Rental Income', 'Income from renting property', 'home', 'INCOME', TRUE, '#795548'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Rental Income' AND user_id IS NULL);

INSERT INTO categories (name, description, icon, type, is_default, color)
SELECT 'Other Income', 'Miscellaneous income sources', 'more_horiz', 'INCOME', TRUE, '#607D8B'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Other Income' AND user_id IS NULL);

-- Create a demo user if one doesn't exist
INSERT INTO users (first_name, last_name, email, password, role)
SELECT 'Demo', 'User', 'demo@example.com', '$2a$10$eDIJJXX0F0lZS2jTBT2JG.AtNdLhesqzE/MvVw0WZ1Aq0fmxBXKZG', 'ROLE_USER'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'demo@example.com');
-- Password is 'password' (hashed with BCrypt)
