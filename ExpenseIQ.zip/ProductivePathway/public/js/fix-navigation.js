/**
 * Fix navigation links for Replit environment
 * This ensures all relative links (/path) work properly in any environment
 */
document.addEventListener('DOMContentLoaded', function() {
  // Fix all navigation links in the document
  const links = document.querySelectorAll('a[href^="/"]');
  
  links.forEach(link => {
    const href = link.getAttribute('href');
    if (href && href.startsWith('/') && !href.startsWith('//')) {
      // Replace the link's click behavior
      link.addEventListener('click', function(e) {
        e.preventDefault();
        
        // First, try to find and remove any 'active' class from current active item
        const currentActive = document.querySelector('.sidebar-link.active');
        if (currentActive) {
          currentActive.classList.remove('active');
        }
        
        // Add active class to clicked link if it's in the sidebar
        if (link.classList.contains('sidebar-link')) {
          link.classList.add('active');
        }
        
        // Handle navigation based on href
        const path = href.endsWith('.html') ? href : `${href}.html`;
        const finalPath = path.startsWith('/') ? path : `/${path}`;
        
        console.log('Navigating to:', finalPath);
        window.location.href = finalPath;
      });
    }
  });

  try {
    // Highlight the current active page in sidebar
    const currentPath = window.location.pathname;
    // Remove .html extension if present for consistent matching
    const cleanPath = currentPath.replace(/\.html$/, '');
    // Default to dashboard if on root
    const normalizedPath = cleanPath === '/' ? '/dashboard' : cleanPath;
    
    console.log('Current path:', normalizedPath);
    
    // Find the matching sidebar link and set it as active
    // Try multiple selectors to ensure we find the right link
    const selectors = [
      `.sidebar-link[href="${normalizedPath}"]`,
      `.sidebar-link[href="${normalizedPath}.html"]`,
      `.sidebar-link[href="${normalizedPath}/"]`
    ];
    
    let matchingSidebarLink = null;
    for (const selector of selectors) {
      matchingSidebarLink = document.querySelector(selector);
      if (matchingSidebarLink) break;
    }
    
    if (matchingSidebarLink) {
      console.log('Setting active sidebar item:', matchingSidebarLink.getAttribute('href'));
      matchingSidebarLink.classList.add('active');
    } else {
      console.log('No matching sidebar link found for:', normalizedPath);
      
      // Try to extract the main section
      const mainSection = normalizedPath.split('/')[1];
      if (mainSection) {
        const partialMatch = document.querySelector(`.sidebar-link[href^="/${mainSection}"]`);
        if (partialMatch) {
          console.log('Found partial match:', partialMatch.getAttribute('href'));
          partialMatch.classList.add('active');
        }
      }
    }
  } catch (err) {
    console.error('Error highlighting active sidebar item:', err);
  }

  console.log('Navigation links fixed for Replit environment');
});