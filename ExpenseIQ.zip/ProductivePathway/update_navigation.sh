#!/bin/bash

# List of HTML files to update
HTML_FILES=(
  "public/transactions.html"
  "public/budgets.html"
  "public/insights.html"
  "public/settings.html"
  "public/goals.html"
  "public/bills.html"
  "public/investments.html"
  "public/reports.html"
  "public/accounts.html"
)

# The string to append before </body>
NAV_FIX='    <!-- Fix navigation links for Replit environment -->
    <script src="/js/fix-navigation.js"></script>'

# Process each file
for file in "${HTML_FILES[@]}"; do
  if [ -f "$file" ]; then
    echo "Processing $file..."
    
    # Check if the fix is already added
    if grep -q "fix-navigation.js" "$file"; then
      echo "  Navigation fix already present in $file, skipping."
    else
      # Add the navigation fix before </body>
      sed -i "s|</body>|${NAV_FIX}\n  </body>|" "$file"
      echo "  Navigation fix added to $file"
    fi
  else
    echo "File $file not found, skipping."
  fi
done

echo "Navigation fix applied to all files."