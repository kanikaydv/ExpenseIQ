# ExpenseIQ - Personal Finance Manager

ExpenseIQ is a comprehensive personal finance management application built with Java, Spring Boot, and Thymeleaf. It helps users track expenses, manage budgets, and gain insights into their financial habits.

## Features

- **User Authentication**: Secure registration and login with encrypted passwords
- **Expense/Income Tracking**: Track expenses and income with custom categories
- **CSV Import**: Import transactions from CSV files
- **Budget Planning**: Set monthly/yearly limits with notifications
- **Interactive Dashboards**: Visualize financial data with charts
- **ML Insights**: Analyze spending trends and get saving tips
- **Investment Suggestions**: Personalized investment recommendations
- **Notifications**: Bill reminders and monthly summaries

## Technology Stack

- **Backend**: Java 17, Spring Boot 3.x, Spring Security, Spring Data JPA
- **Frontend**: Thymeleaf, HTML5, CSS3, JavaScript, Chart.js
- **Database**: PostgreSQL
- **Build Tool**: Maven

## Getting Started

### Prerequisites

- Java 17 or higher
- PostgreSQL database
- Maven

### Installation

1. Clone the repository
2. Configure your database connection in `application.properties`
3. Run `mvn clean install` to build the project
4. Start the application with `mvn spring-boot:run`
5. Access the application at http://localhost:8080

### Environment Variables

The application uses the following environment variables for database configuration:

- `PGHOST`: PostgreSQL host
- `PGPORT`: PostgreSQL port
- `PGDATABASE`: PostgreSQL database name
- `PGUSER`: PostgreSQL username
- `PGPASSWORD`: PostgreSQL password

## Project Structure

The project follows a modular MVC architecture:

- `model`: Entity classes that map to database tables
- `repository`: Data access interfaces
- `service`: Business logic implementation
- `controller`: Request handling and view logic
- `dto`: Data transfer objects for API communication
- `exception`: Custom exception classes and handlers
- `util`: Utility classes for common functionality
- `resources/templates`: Thymeleaf templates for the UI

## Design Elements

- **Color Scheme**: Forest Green (#2E7D32), Blue (#1976D2), Soft White (#F5F7FA), Grey (#263238), Orange (#FF9800)
- **Layout**: Card-based dashboard with 16px spacing and shadow effects
- **Font**: SF Pro Display / Inter

## License

This project is a final-year academic project and is free to use for educational purposes.

## Acknowledgments

- Inspired by Mint & Personal Capital dashboards
- Built with Spring Boot for robust backend architecture
- Styled with modern design principles for optimal user experience
